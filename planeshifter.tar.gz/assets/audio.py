"""Tiny synthesizer: every sound in the game is generated at startup."""

import math
import random
import sys
import threading
import time
from array import array

import pygame

RATE = 22050
LOOP_SECONDS = 4.0  # ambient loops; all frequencies are multiples of 1/4 Hz


def _q(f):
    """Round a frequency so it completes whole cycles in one loop (seamless)."""
    return round(f * LOOP_SECONDS) / LOOP_SECONDS


# Each pad: list of (frequency, amplitude, tremolo_hz)
PADS = {
    "home": [(_q(120), 0.10, 0.0), (_q(240), 0.03, 0.0), (_q(261.6), 0.07, 0.25),
             (_q(329.6), 0.05, 0.5), (_q(392.0), 0.05, 0.25), (_q(493.9), 0.03, 0.75)],
    "sollow": [(_q(440.0), 0.07, 0.25), (_q(659.3), 0.06, 0.5), (_q(987.8), 0.04, 0.75),
               (_q(1318.5), 0.025, 0.25), (_q(220.0), 0.05, 0.25)],
    "hesk": [(_q(73.4), 0.14, 0.25), (_q(110.0), 0.10, 0.25), (_q(110.5), 0.08, 0.0),
             (_q(174.6), 0.06, 0.5), (_q(220.0), 0.04, 0.25), (_q(261.6), 0.03, 0.75)],
    "ambrine": [(_q(174.6), 0.09, 0.5), (_q(220.0), 0.08, 0.25), (_q(261.6), 0.07, 0.5),
                (_q(349.2), 0.05, 0.75), (_q(440.0), 0.04, 1.0), (_q(523.3), 0.03, 0.25)],
}


class Audio:
    def __init__(self):
        self.ok = pygame.mixer.get_init() is not None
        self.muted = False
        self.sounds = {}
        self.pads = {}
        self.current_pad = None
        self.channels = 1
        self._pad_work = None
        if not self.ok:
            return
        self.rate, _, self.channels = pygame.mixer.get_init()
        self.pad_channel = pygame.mixer.Channel(0)
        pygame.mixer.set_reserved(1)
        self._build_sfx()
        if sys.platform == "emscripten":
            # Browser build has no threads: update() builds the pads a slice per frame.
            self._pad_work = self._build_pads()
        else:
            threading.Thread(target=self._build_all_pads, daemon=True).start()

    # -- building -------------------------------------------------------------
    def _make(self, samples):
        """Turn floats in [-1, 1] at RATE into a pygame Sound for the mixer's format."""
        step = RATE / self.rate
        out = array("h")
        n = int(len(samples) / step)
        for i in range(n):
            v = samples[int(i * step)]
            v = max(-1.0, min(1.0, v))
            s = int(v * 32000)
            for _ in range(self.channels):
                out.append(s)
        return pygame.mixer.Sound(buffer=out.tobytes())

    def _build_sfx(self):
        # dialogue blip
        n = int(RATE * 0.03)
        blip = [math.sin(2 * math.pi * 880 * i / RATE) * (1 - i / n) * 0.25 for i in range(n)]
        self.sounds["blip"] = self._make(blip)
        # plane shift: a falling-then-rising shimmer
        n = int(RATE * 1.1)
        rnd = random.Random(7)
        shift = []
        phase = 0.0
        for i in range(n):
            p = i / n
            f = 220 + 660 * (1 - p) ** 2 + 330 * p ** 3
            phase += 2 * math.pi * f / RATE
            env = math.sin(math.pi * p) ** 1.5
            v = math.sin(phase) * 0.35 + math.sin(phase * 1.5) * 0.15
            v += (rnd.random() - 0.5) * 0.08 * env
            shift.append(v * env * (0.7 + 0.3 * math.sin(2 * math.pi * 9 * p)))
        self.sounds["shift"] = self._make(shift)
        # understanding chime: three rising bell notes
        n = int(RATE * 2.2)
        chime = [0.0] * n
        for k, (f, start) in enumerate([(523.3, 0.0), (659.3, 0.18), (784.0, 0.36), (1046.5, 0.54)]):
            s0 = int(start * RATE)
            for i in range(s0, n):
                t = (i - s0) / RATE
                env = math.exp(-t * 2.4)
                chime[i] += (math.sin(2 * math.pi * f * t) + 0.3 * math.sin(2 * math.pi * f * 2.01 * t)) * env * 0.16
        self.sounds["chime"] = self._make(chime)
        # soft notification pop
        n = int(RATE * 0.35)
        pop = []
        for i in range(n):
            t = i / RATE
            f = 660 if t < 0.12 else 880
            pop.append(math.sin(2 * math.pi * f * t) * math.exp(-t * 9) * 0.25)
        self.sounds["pop"] = self._make(pop)
        # menu tick
        n = int(RATE * 0.05)
        self.sounds["tick"] = self._make(
            [math.sin(2 * math.pi * 1320 * i / RATE) * (1 - i / n) * 0.18 for i in range(n)])

    def _build_all_pads(self):
        for _ in self._build_pads():
            pass

    def _build_pads(self, chunk=4096):
        """Generator: yields every `chunk` samples so the work can be spread across frames."""
        n = int(RATE * LOOP_SECONDS)
        for name, partials in PADS.items():
            data = [0.0] * n
            for f, amp, trem in partials:
                w = 2 * math.pi * f / RATE
                tw = 2 * math.pi * trem / RATE
                for i in range(n):
                    a = amp * (0.75 + 0.25 * math.sin(tw * i)) if trem else amp
                    data[i] += math.sin(w * i) * a
                    if i % chunk == 0:
                        yield
            try:
                self.pads[name] = self._make(data)
            except pygame.error:
                return
            yield

    # -- playback ---------------------------------------------------------------
    def play(self, name, volume=1.0):
        if not self.ok or self.muted or name not in self.sounds:
            return
        snd = self.sounds[name]
        snd.set_volume(volume)
        snd.play()

    def set_plane(self, plane):
        """Crossfade to a plane's ambient pad (if it has finished generating)."""
        if not self.ok:
            return
        self.current_pad = plane
        if self.muted:
            return
        pad = self.pads.get(plane)
        if pad is None:
            return
        pad.set_volume(0.55)
        self.pad_channel.fadeout(300)
        self.pad_channel.play(pad, loops=-1, fade_ms=900)

    def update(self):
        """Start the pad once background generation has caught up."""
        if self._pad_work is not None:
            end = time.perf_counter() + 0.006
            for _ in self._pad_work:
                if time.perf_counter() > end:
                    break
            else:
                self._pad_work = None
        if self.ok and not self.muted and self.current_pad and not self.pad_channel.get_busy():
            if self.current_pad in self.pads:
                self.set_plane(self.current_pad)

    def toggle_mute(self):
        if not self.ok:
            return
        self.muted = not self.muted
        if self.muted:
            pygame.mixer.stop()
        else:
            self.set_plane(self.current_pad)
