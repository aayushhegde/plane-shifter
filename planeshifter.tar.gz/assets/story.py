"""
Plane Shifter: every word in the game lives here.

The world is one small room (Gate 14) that exists in four planes. The same
six people stand in the same places in every plane, but their names, roles,
and cultures change. Only Teodor, a fellow traveler, stays the same.

Dialogue format
---------------
DIALOGUE[(plane, npc)] is a list of entries. When the player talks to someone,
the first entry whose conditions pass is played. An entry with `once` plays a
single time. Conditions are strings:
    "flag"      flag is set            "!flag"      flag is not set
    "has:item"  player carries item    "seen:key"   a `once` entry has played
Steps are tuples built by the helpers below.
"""

# --------------------------------------------------------------------------
# Step helpers
# --------------------------------------------------------------------------

def say(who, text):
    return ("say", who, text)


def you(text):
    return ("say", "you", text)


def nar(text):
    return ("nar", text)


def flag(*names):
    return ("set", names)


def note(plane, text):
    return ("note", plane, text)


def give(item):
    return ("give", item)


def take(item):
    return ("take", item)


def understand(plane):
    return ("understand", plane)


def choice(*options):
    return ("choice", options)


def toast(text):
    return ("toast", text)


END = ("end",)


def E(steps, when=(), once=None):
    return {"steps": steps, "when": tuple(when), "once": once}


# --------------------------------------------------------------------------
# The map: one room, four planes
# --------------------------------------------------------------------------
# '#' wall   '.' floor   'W' window   'K' board / wall of meaning
# 'B' benches   'C' counter   'D' desk   'P' plant   'F' centrepiece   'G' door

LAYOUT = [
    "##WWWWWWWW##KKKKKK##WWWWWWWW##",
    "##WWWWWWWW##KKKKKK##WWWWWWWW##",
    "#............................#",
    "#.P........................P.#",
    "#............................#",
    "#...BBBBBB..........BBBBBB...#",
    "#............................#",
    "#............FFFF............G",
    "#............FFFF............G",
    "#............FFFF............G",
    "#............................#",
    "#............................#",
    "#...BBBBBB..........BBBBBB...#",
    "#............................#",
    "#CCCCCC..................DDDD#",
    "#.....C..................D...#",
    "#.....C..........P.......D...#",
    "##############################",
]

PLAYER_START = (15, 11)

PLANES = ["home", "sollow", "hesk", "ambrine"]
STORY_PLANES = ["sollow", "hesk", "ambrine"]

PLANE_INFO = {
    "home": {
        "name": "Gate 14",
        "long": "Gate 14, Terminal C",
        "epithet": "Your own plane. Delayed.",
        "color": (122, 156, 196),
        "understanding": None,
    },
    "sollow": {
        "name": "Sollow",
        "long": "Sollow",
        "epithet": "The Plane of Counted Words",
        "color": (176, 208, 238),
        "understanding": (
            "In Sollow, every person is given a limited number of words for "
            "their whole life. So no one wastes speech, and silence is not "
            "emptiness. It is a language of its own."
        ),
    },
    "hesk": {
        "name": "Hesk",
        "long": "Hesk",
        "epithet": "The Plane of Shared Dreams",
        "color": (170, 140, 240),
        "understanding": (
            "In Hesk, the whole village dreams one dream. No secret stays "
            "private, so kindness is not a luxury there. It is survival: "
            "whatever one person hides, everyone has to sleep inside."
        ),
    },
    "ambrine": {
        "name": "Ambrine",
        "long": "Ambrine",
        "epithet": "The Plane of Giving",
        "color": (242, 170, 84),
        "understanding": (
            "In Ambrine, owning is shameful and giving is honor. Nothing is "
            "kept, only held for a while. A gift isn't the object. It is the "
            "passing of it, and receiving is part of the gift."
        ),
    },
}

ITEMS = {
    "lemon cake": "A lemon cake from the Gate 14 café. Free, because nobody ever asks.",
    "carved bird": "Pim's carved wooden bird, worn smooth from three seasons of holding.",
}

# --------------------------------------------------------------------------
# People
# --------------------------------------------------------------------------
# Looks are drawn procedurally by art.py.

def _look(**kw):
    base = {
        "skin": (200, 160, 130), "hair": (60, 45, 35), "hair_style": "short",
        "top": (90, 90, 110), "bottom": (50, 50, 60), "accent": None,
        "accessory": None, "child": False,
    }
    base.update(kw)
    return base


TEODOR_LOOK = _look(skin=(150, 110, 85), hair=(120, 120, 125), hair_style="short",
                    top=(72, 84, 100), bottom=(60, 70, 84), accent=(222, 186, 60),
                    accessory="mop")

PLAYER_LOOK = _look(skin=(214, 172, 140), hair=(74, 50, 36), hair_style="short",
                    top=(52, 112, 128), bottom=(48, 52, 66), accent=(232, 214, 170),
                    accessory="none")

NPCS = {
    "teodor": {
        "pos": (10, 10),
        "names": {p: "Teodor" for p in PLANES},
        "roles": {p: "a traveler, unchanged" for p in PLANES},
        "looks": {p: TEODOR_LOOK for p in PLANES},
    },
    "marisol": {
        "pos": (27, 15),
        "names": {"home": "Marisol", "sollow": "Maro", "hesk": "Mira", "ambrine": "Amarys"},
        "roles": {"home": "gate agent", "sollow": "the Counter",
                  "hesk": "the Dream-Reader", "ambrine": "the Ledger"},
        "looks": {
            "home": _look(skin=(190, 140, 110), hair=(40, 28, 26), hair_style="bun",
                          top=(40, 56, 104), bottom=(34, 40, 62), accent=(196, 52, 52),
                          accessory="scarf_knot"),
            "sollow": _look(skin=(190, 140, 110), hair=(40, 28, 26), hair_style="hood",
                            top=(206, 210, 220), bottom=(150, 160, 180), accent=(96, 116, 156)),
            "hesk": _look(skin=(190, 140, 110), hair=(40, 28, 26), hair_style="long",
                          top=(150, 128, 204), bottom=(120, 100, 170), accent=(240, 220, 150)),
            "ambrine": _look(skin=(190, 140, 110), hair=(40, 28, 26), hair_style="wrap",
                             top=(232, 160, 48), bottom=(160, 70, 52), accent=(180, 52, 60),
                             accessory="quill"),
        },
    },
    "ruth": {
        "pos": (7, 12),
        "seated": True,
        "names": {"home": "Ruth", "sollow": "Rue", "hesk": "Old Ru", "ambrine": "Grandmother"},
        "roles": {"home": "knitting through the delay", "sollow": "the Wordless",
                  "hesk": "the oldest dreamer", "ambrine": "who gave her name away"},
        "looks": {
            "home": _look(skin=(226, 192, 172), hair=(222, 222, 228), hair_style="bun",
                          top=(152, 90, 112), bottom=(82, 70, 92), accent=(70, 110, 190),
                          accessory="knitting"),
            "sollow": _look(skin=(226, 192, 172), hair=(240, 240, 244), hair_style="hood",
                            top=(232, 236, 242), bottom=(170, 176, 190), accent=(70, 110, 190),
                            accessory="long_scarf"),
            "hesk": _look(skin=(226, 192, 172), hair=(222, 222, 228), hair_style="long",
                          top=(112, 140, 192), bottom=(80, 100, 150), accent=(200, 190, 240),
                          accessory="knitting"),
            "ambrine": _look(skin=(226, 192, 172), hair=(222, 222, 228), hair_style="wrap",
                             top=(204, 120, 62), bottom=(150, 80, 50), accent=(60, 130, 140),
                             accessory="knitting"),
        },
    },
    "pip": {
        "pos": (5, 2),
        "names": {"home": "Pip", "sollow": "Pell", "hesk": "Pippa", "ambrine": "Pim"},
        "roles": {"home": "a kid with a toy plane", "sollow": "a child before her Count",
                  "hesk": "a child who has never dreamed alone",
                  "ambrine": "a child with a secret"},
        "looks": {
            "home": _look(skin=(120, 84, 60), hair=(30, 24, 20), hair_style="puffs",
                          top=(242, 200, 60), bottom=(60, 90, 160), accessory="toy_plane",
                          child=True),
            "sollow": _look(skin=(120, 84, 60), hair=(30, 24, 20), hair_style="hood",
                            top=(180, 202, 232), bottom=(120, 140, 170), accent=(240, 240, 250),
                            accessory="feather", child=True),
            "hesk": _look(skin=(120, 84, 60), hair=(30, 24, 20), hair_style="puffs",
                          top=(206, 172, 226), bottom=(170, 140, 200), accessory="lantern",
                          child=True),
            "ambrine": _look(skin=(120, 84, 60), hair=(30, 24, 20), hair_style="wrap",
                             top=(222, 92, 80), bottom=(232, 190, 90), accent=(60, 130, 140),
                             accessory="bird", child=True),
        },
    },
    "dev": {
        "pos": (3, 15),
        "names": {"home": "Dev", "sollow": "Devo", "hesk": "Deven", "ambrine": "Dov"},
        "roles": {"home": "barista", "sollow": "the Teamaker",
                  "hesk": "the dream baker", "ambrine": "the Breadgiver"},
        "looks": {
            "home": _look(skin=(170, 120, 90), hair=(22, 20, 26), hair_style="short",
                          top=(44, 44, 50), bottom=(36, 36, 42), accent=(130, 84, 52),
                          accessory="apron"),
            "sollow": _look(skin=(170, 120, 90), hair=(22, 20, 26), hair_style="short",
                            top=(130, 150, 172), bottom=(90, 100, 120), accent=(210, 200, 180),
                            accessory="apron"),
            "hesk": _look(skin=(170, 120, 90), hair=(22, 20, 26), hair_style="cap",
                          top=(240, 236, 226), bottom=(200, 196, 190), accent=(250, 250, 250),
                          accessory="apron"),
            "ambrine": _look(skin=(170, 120, 90), hair=(22, 20, 26), hair_style="short",
                             top=(240, 220, 170), bottom=(140, 90, 60), accent=(210, 150, 80),
                             accessory="bread"),
        },
    },
    "hale": {
        "pos": (23, 3),
        "pace": {"home": (20, 26)},
        "seated_in": ("hesk", "ambrine"),
        "names": {"home": "Mr. Hale", "sollow": "Hollis", "hesk": "Harlan",
                  "ambrine": "Hollan"},
        "roles": {"home": "on the phone, pacing", "sollow": "the Spent",
                  "hesk": "the one who came back", "ambrine": "the Poorest Man"},
        "looks": {
            "home": _look(skin=(232, 196, 170), hair=(112, 82, 52), hair_style="short",
                          top=(62, 62, 74), bottom=(46, 46, 56), accent=(150, 32, 44),
                          accessory="phone"),
            "sollow": _look(skin=(232, 196, 170), hair=(112, 82, 52), hair_style="short",
                            top=(122, 92, 112), bottom=(80, 64, 80), accent=(40, 40, 46),
                            accessory="slate"),
            "hesk": _look(skin=(232, 196, 170), hair=(112, 82, 52), hair_style="messy",
                          top=(170, 170, 194), bottom=(130, 130, 160), accessory="box"),
            "ambrine": _look(skin=(232, 196, 170), hair=(112, 82, 52), hair_style="short",
                             top=(238, 232, 216), bottom=(200, 190, 170)),
        },
    },
}

# --------------------------------------------------------------------------
# Intro and ending
# --------------------------------------------------------------------------

INTRO_SLIDES = [
    "Gate 14, Terminal C.",
    "Flight 1407 to Portland has been delayed. Then delayed again. "
    "Then the word DELAYED stopped meaning anything at all.",
    "You have read every sign twice. You have eaten an eleven-dollar sandwich. "
    "You have been waiting so long that something in you has begun to come loose.",
    "Some travelers say this exact feeling is a door: the tiredness, the bad "
    "coffee, the waiting with nothing to wait for.",
    "If you know how to turn, you can step sideways out of the airport and "
    "into another plane of existence entirely.",
    "You don't know how to turn. Not yet.",
]


def ending_slides(state):
    return [
        "Flight 1407 lifts off into the rain. Below you, Gate 14 shrinks to a "
        "lit rectangle, then a pinprick, then nothing.",
        "In Sollow, Pell is talking: loudly, freely, for one more day. Tomorrow "
        "her name will be carved on the Wall of Counts. She isn't afraid of the "
        "silence after.",
        "In Hesk, the whole village sleeps soundly for the first time in weeks. "
        "Tonight, they are all dreaming of a long road home.",
        "In Ambrine, a carved wooden bird begins a brand-new season with the "
        "same small owner. The Ledger records it twice.",
        "And at Gate 14, a man calls his wife. A woman knits a message into a "
        "scarf. A barista gives away cake nobody asked for. A child flies a toy "
        "plane to other worlds.",
        "A visitor from Sollow would find Gate 14 very strange: hundreds of "
        "strangers sitting side by side, saying almost nothing, each carrying a "
        "box they cannot put down.",
        "They would write it down in their journal. They would try very hard "
        "to understand us.",
    ]


CREDITS = [
    "PLANE SHIFTER",
    "A creative project inspired by Ursula K. Le Guin's",
    "Changing Planes (2003)",
    "",
    "Made with Python and Pygame",
    "Thank you for traveling.",
]

# --------------------------------------------------------------------------
# Teodor: the one person who never changes
# --------------------------------------------------------------------------

def _plane_hint(plane, s):
    f, items = s.flags, s.items
    if plane == "sollow":
        if "saw_scarf" not in f:
            return ("In Sollow, words are counted. Visit the old woman knitting on "
                    "the bench there. Her hands do all of her talking now.")
        if "know_stitch" not in f:
            return ("That scarf in Sollow? Somebody at Gate 14 knits, too. Same "
                    "hands, different world. Ask her about it.")
        if "read_scarf" not in f:
            return "You know how to read stitches now. Go read Rue's scarf in Sollow."
        return "That scarf was never meant for you. Take its message to the child in Sollow."
    if plane == "hesk":
        if "heard_nightmare" not in f:
            return ("In Hesk, everybody dreams the same dream. Ask the Dream-Reader "
                    "what's been keeping them up.")
        if "hale_secret" not in f:
            return ("Someone in Hesk is carrying a box they won't open. Someone at "
                    "Gate 14 is too. Talk to the man pacing by the window, and "
                    "talk to him more than once.")
        if "harlan_confessed" not in f:
            return ("You know what was in Mr. Hale's box. Harlan, in Hesk, is "
                    "carrying the same weight.")
        return "Go see the Dream-Reader in Hesk. That nightmare has an owner now."
    if plane == "ambrine":
        if "know_ledger" not in f:
            return ("In Ambrine, you're nobody until you've given something away. "
                    "The Ledger will explain.")
        if "gave_cake" not in f and "lemon cake" not in items:
            return ("You can't give what you don't have. Back at Gate 14, somebody "
                    "behind a counter hands out free things to stranded people.")
        if "gave_cake" not in f:
            return ("Give that lemon cake to whoever in Ambrine has the least. "
                    "You'll know him. Everyone bows to him.")
        if "carved bird" not in items:
            return ("The child in Ambrine has something she can't bear to part "
                    "with. Listen to her, and remember what Grandmother says "
                    "about two hands.")
        return "In Ambrine, a gift that comes back is a brand-new gift."
    return ""


TEODOR_PREFIX = {
    "home": "Here's a tip from an old traveler.",
    "sollow": "(He whispers. Visitors' words don't count, but he says it's polite.)",
    "hesk": "Keep it soft. Half of them are napping.",
    "ambrine": "Still dragging that suitcase around? Bless you.",
}


def teodor_hint(s):
    if "all_done" in s.flags:
        return [
            say("teodor", "You've got that look. Like the room's gone strange around the edges."),
            say("teodor", "That's the real souvenir. You come home, and home looks like "
                          "another plane. Go on, check the departures board."),
        ]
    if not (s.visited - {"home"}):
        return [say("teodor", "Go on, press SHIFT. The room will still be here when "
                              "you get back. It's always here.")]
    order = [s.plane] if s.plane in STORY_PLANES else []
    order += STORY_PLANES
    for plane in order:
        if f"{plane}_done" not in s.flags and plane in s.visited:
            return [say("teodor", TEODOR_PREFIX[s.plane]), say("teodor", _plane_hint(plane, s))]
    for plane in STORY_PLANES:
        if plane not in s.visited:
            name = PLANE_INFO[plane]["name"]
            return [say("teodor", f"You haven't been to {name} yet. Press SHIFT and "
                                  f"pick it. Bring your patience.")]
    return [say("teodor", "Keep turning. You'll see it.")]


# --------------------------------------------------------------------------
# Dialogue
# --------------------------------------------------------------------------

DIALOGUE = {}

# ============================== GATE 14 ===================================

DIALOGUE[("home", "teodor")] = [
    E(once="teo_intro", steps=[
        nar("A janitor leans on his mop, watching the departures board the way "
            "some people watch the sea."),
        say("teodor", "Delayed again, huh? 1407?"),
        you("Six hours now. Maybe more."),
        say("teodor", "Good. That's good. You're just about bored enough."),
        you("Bored enough for what?"),
        say("teodor", "To leave. Not the airport. The airport never lets anybody "
                      "leave. I mean leave sideways."),
        say("teodor", "A woman named Sita Dulip worked it out years ago, stuck at a "
                      "gate like this one. The waiting loosens you up. Twist just "
                      "right, and you slip into another plane."),
        you("You're joking."),
        say("teodor", "Try it. Press SHIFT and turn. Same room, same people, more "
                      "or less. Different everything else."),
        say("teodor", "Me, I've been doing it for years. I'm the same in every "
                      "plane, though. Travelers don't change. Changing is the job "
                      "of the people who live there."),
        flag("can_shift"),
        toast("You can now change planes: press SHIFT"),
        note("home", "Teodor, a janitor, taught me the method: bored enough in an "
                     "airport, you can slip sideways into other planes."),
    ]),
    E(steps=teodor_hint),
]

DIALOGUE[("home", "marisol")] = [
    E(when=("all_done",), steps=[
        say("marisol", "There you are! Flight 1407 is boarding. Funny thing: the "
                       "system just cleared. Like it was waiting on something."),
        choice(
            ("Board Flight 1407", [
                nar("You hand Marisol your boarding pass. For a moment her eyes "
                    "look like Maro's, and Mira's, and Amarys's, all at once."),
                say("marisol", "Have a good flight. Wherever you end up."),
                END,
            ]),
            ("Not yet", [
                say("marisol", "Don't take too long. Doors close eventually. Even here."),
            ]),
        ),
    ]),
    E(once="marisol_intro", steps=[
        nar("The gate agent types without looking at her screen. Her name tag "
            "says MARISOL."),
        say("marisol", "If you're asking about 1407 to Portland: delayed. If you're "
                       "asking how long: I don't know. If you're asking why: it's "
                       "an airport."),
        you("Is there anything I can do?"),
        say("marisol", "Wait. Everyone here is very good at it. It's the main thing we do."),
        note("home", "Flight 1407 to Portland is delayed indefinitely. Nobody knows why."),
    ]),
    E(when=("any_done",), steps=[
        say("marisol", "Still delayed. But the board keeps flickering. That's "
                       "usually a good sign. Or a broken board."),
    ]),
    E(steps=[
        say("marisol", "Still delayed. Would you like a meal voucher? It's for "
                       "twelve dollars. Nothing here costs twelve dollars."),
    ]),
]

DIALOGUE[("home", "ruth")] = [
    E(when=("saw_scarf", "!know_stitch"), once="ruth_teach", steps=[
        you("Can I ask you something odd? Can knitting say something? Like a message?"),
        say("ruth", "Ha! Now where did you hear about that?"),
        say("ruth", "My grandmother lost her hearing young. She used to knit little "
                    "notes into our mittens. Bumps and dips."),
        say("ruth", "A knit stitch is a dot. A purl stitch is a dash. It's Morse "
                    "code, sweetheart, only with yarn. Spies did it in the war, too."),
        nar("She guides your finger along a row of her scarf. Dip, dip. Bump, "
            "dip. Dip, bump, dip, dip. Bump, dip. It spells a name: MAYA."),
        say("ruth", "There. Now you can read any scarf in the world."),
        flag("know_stitch"),
        toast("You can now read knitted messages"),
        note("home", "Ruth taught me stitch-talk: a knit stitch is a dot, a purl "
                     "stitch is a dash. Morse code in yarn."),
    ]),
    E(once="ruth_intro", steps=[
        nar("An older woman knits something long and blue. Her needles never stop."),
        say("ruth", "Sit, sit. You're making me tired just standing there."),
        say("ruth", "It's a scarf for my granddaughter. I've knitted straight "
                    "through three delays. At this rate she'll be getting a blanket."),
        note("home", "Ruth knits on the bench. She's been here through three delays."),
    ]),
    E(when=("sollow_done",), once="ruth_after", steps=[
        say("ruth", "You've got a faraway look."),
        say("ruth", "You know, I talk less every year. Not because I have less to "
                    "say. I've just learned which things really need saying."),
    ]),
    E(steps=[
        say("ruth", "Knit, purl, knit, purl. You'd be amazed what you can say "
                    "without saying a word."),
    ]),
]

DIALOGUE[("home", "pip")] = [
    E(once="pip_intro", steps=[
        nar("A kid zooms a toy airplane along the window, making engine noises "
            "with total seriousness."),
        say("pip", "Vrrrrrm. This is Flight 1407. It's not delayed. It goes to other worlds."),
        you("Which worlds?"),
        say("pip", "All of them! One where it snows inside. One where it's always "
                   "night. One where everybody gives you stuff."),
        note("home", "Pip plays with a toy plane by the window. Pip says it flies "
                     "to other worlds."),
    ]),
    E(when=("pim_asked", "!ambrine_done"), once="pip_lend", steps=[
        say("pip", "Wanna know a secret? Sometimes I give my plane to my friend "
                   "Ana for a day. Then she gives it back."),
        say("pip", "When it comes back it feels brand new. Like a present again. "
                   "Same plane, though."),
        note("home", "Pip says when a toy is given away and then given back, it "
                     "feels like a brand-new present."),
    ]),
    E(when=("all_done",), steps=[
        say("pip", "My flight's boarding! The real one. I'm sitting by the window "
                   "so I can look for the other worlds."),
    ]),
    E(steps=[
        say("pip", "Vrrrrm. Do you think the other worlds have airports? I bet "
                   "they're nicer airports."),
    ]),
]

DIALOGUE[("home", "dev")] = [
    E(once="dev_intro", steps=[
        nar("The barista has the calm of someone who has served four hundred "
            "people the same delay."),
        say("dev", "Hey. You've been here a while, huh? 1407?"),
        you("Six hours."),
        say("dev", "Here."),
        nar("He slides a lemon cake across the counter."),
        say("dev", "On the house. We're supposed to give these out when a delay "
                   "goes past five hours. Nobody ever asks, so nobody ever gets one."),
        give("lemon cake"),
        note("home", "Dev, the barista, gave me a free lemon cake. 'Nobody ever "
                     "asks, so nobody ever gets one.'"),
    ]),
    E(when=("gave_cake",), once="dev_cake", steps=[
        say("dev", "How was the cake?"),
        you("I gave it away, actually. To a man who owned exactly one shirt."),
        say("dev", "...Huh. Honestly? That's the best review that cake has ever gotten."),
    ]),
    E(steps=[
        say("dev", "Coffee's terrible today. Same as yesterday. Consistency is a "
                   "kind of comfort, I guess."),
    ]),
]

DIALOGUE[("home", "hale")] = [
    E(once="hale_phone", steps=[
        nar("A man in a pressed suit paces by the window, phone pressed to his ear."),
        say("hale", "No, honey, it went great. Great meeting. Big things coming. "
                    "I'll tell you everything when I'm home. Love you. Bye."),
        nar("He hangs up and stares at the phone like it bit him."),
        say("hale", "Sorry. Didn't mean to pace into you. It's been a week."),
        note("home", "Mr. Hale paces by the window, telling someone on the phone "
                     "that everything is 'great.'"),
    ]),
    E(when=("seen:hale_phone",), once="hale_confess", steps=[
        say("hale", "You ever tell somebody you love a small lie, and then it "
                    "just keeps getting heavier?"),
        you("What happened?"),
        nar("He glances at his carry-on. Through the open zipper you can see a "
            "cardboard box: a desk plant, a framed photo, a mug."),
        say("hale", "They let me go. Tuesday. Twenty-two years. They gave me a box "
                    "for my desk things. That's how you know. They give you a box."),
        say("hale", "My wife thinks I'm flying home from a big meeting. I keep "
                    "saying I'll tell her at the gate. Then the flight gets "
                    "delayed, and I get another hour of not telling her."),
        say("hale", "I haven't slept since Tuesday. Every time I close my eyes, I "
                    "see that box falling."),
        flag("hale_secret"),
        note("home", "Mr. Hale lost his job and hasn't told his wife. He carries "
                     "his desk things in a box and dreams of it falling."),
    ]),
    E(when=("hesk_done",), once="hale_after", steps=[
        say("hale", "Hey, you. I called her. My wife. I told her everything."),
        say("hale", "She was quiet for a long time. Then she said, 'Come home, "
                    "we'll figure it out.' Like it was ours, not just mine."),
        say("hale", "I feel like I could sleep for a week."),
        note("home", "Mr. Hale finally told his wife the truth. It became 'ours, "
                     "not just mine.'"),
    ]),
    E(when=("hesk_done",), steps=[
        say("hale", "Turns out the box wasn't that heavy. It was just a box."),
    ]),
    E(when=("hale_secret",), steps=[
        say("hale", "Another delay. Another hour I don't have to say it. It's "
                    "starting to feel less like luck."),
    ]),
    E(steps=[say("hale", "Sorry. Long week.")]),
]

# =============================== SOLLOW ===================================

DIALOGUE[("sollow", "teodor")] = [
    E(once="teo_sollow", steps=[
        say("teodor", "Told you. Same old me."),
        say("teodor", "Everyone else, though: notice how carefully they listen? "
                      "Like every word costs something. Here, it does."),
    ]),
    E(steps=teodor_hint),
]

DIALOGUE[("sollow", "marisol")] = [
    E(once="maro_intro", steps=[
        nar("A woman stands at a stone lectern over an enormous book. When she "
            "speaks, she reads aloud from its pages, tracing each line with a finger."),
        say("marisol", "'Welcome, traveler. These words are written, not spoken. "
                       "Reading aloud is not counted.'"),
        you("Counted?"),
        say("marisol", "'In Sollow, each child receives a Count at twelve years of "
                       "age: the number of words they will speak in their life. "
                       "Some are given many. Some are given few. When they are "
                       "spent, they are spent.'"),
        say("marisol", "'Your words, visitor, are not counted. Forgive us: to our "
                       "ears they sound like birdsong. Pleasant. Weightless.'"),
        flag("know_count"),
        note("sollow", "Every Sollowan receives a Count at twelve: the number of "
                       "words they may speak in their whole life."),
        note("sollow", "Maro the Counter only speaks by reading aloud from the "
                       "Book. Written words aren't counted."),
        note("sollow", "To Sollowans, a foreigner's free chatter sounds like "
                       "birdsong: pleasant, but weightless."),
    ]),
    E(when=("sollow_done",), once="maro_after", steps=[
        say("marisol", "'The child Pell spoke today. The Book does not record "
                       "free words.'"),
        nar("She closes the Book. Then, very quietly, she spends two words of her own."),
        say("marisol", "Thank you."),
        note("sollow", "Maro spent two of her own words to thank me."),
    ]),
    E(when=("!sollow_done",), once="maro_pell", steps=[
        say("marisol", "'The child Pell receives her Count tomorrow. Until then, "
                       "her words are free, like rain. Yet she has stopped speaking.'"),
        say("marisol", "'She is practicing being careful. The Book has no page for that.'"),
        note("sollow", "Pell's Count is tomorrow. Her words are still free, but "
                       "she has stopped speaking out of fear."),
    ]),
    E(steps=[
        say("marisol", "'Speak freely, visitor. It costs you nothing. That is what "
                       "makes it so strange to us.'"),
    ]),
]

DIALOGUE[("sollow", "ruth")] = [
    E(once="rue_intro", steps=[
        nar("An old woman knits on the bench, a scarf so long it pools around her "
            "feet like snow. She smiles at you, but says nothing."),
        nar("Beside her name on the Wall of Counts, the number has been worn down "
            "to zero. She spent her last word years ago."),
        nar("Her scarf has an odd texture: raised stitches and sunken ones in "
            "uneven rows. Almost like writing."),
        flag("saw_scarf"),
        note("sollow", "Rue spent her last word years ago. Now she only knits. "
                       "Her scarf has a pattern that looks like writing."),
    ]),
    E(when=("know_stitch", "!read_scarf"), once="rue_read", steps=[
        nar("You run a finger along the scarf the way Ruth showed you. Bump: a "
            "knit. Dip: a purl. Dot and dash."),
        nar("Letter by letter, a message rises out of the wool:"),
        nar("FOR PELL.  I SAID MY BEST THINGS AFTER MY WORDS RAN OUT."),
        nar("Rue watches you read it. Then she nods toward the window, where a "
            "child stands with her lips pressed tight."),
        flag("read_scarf"),
        note("sollow", "Rue's scarf says: 'FOR PELL. I SAID MY BEST THINGS AFTER "
                       "MY WORDS RAN OUT.'"),
    ]),
    E(when=("sollow_done",), once="rue_after", steps=[
        nar("Rue loops the end of her scarf once around your neck, holds it there "
            "a moment, then takes it back, smiling."),
        nar("It is the warmest you have felt in any plane."),
    ]),
    E(when=("saw_scarf", "!know_stitch"), steps=[
        nar("The stitches rise and sink under your fingers. You can't read them. "
            "Maybe someone who knits could teach you."),
    ]),
    E(when=("read_scarf", "!sollow_done"), steps=[
        nar("Rue knits on, waiting. She glances at Pell, then back at you."),
    ]),
    E(steps=[nar("Rue knits. Click, click. It sounds almost like talking.")]),
]

DIALOGUE[("sollow", "pip")] = [
    E(when=("read_scarf", "!sollow_done"), once="pell_speaks", steps=[
        you("Pell? Rue knitted something for you. Into her scarf. Do you want "
            "to know what it says?"),
        nar("Pell goes very still. Then she nods, once."),
        you("It says: 'I said my best things after my words ran out.'"),
        nar("Pell looks across the room at Rue. Rue lifts her needles in a tiny salute."),
        nar("Something in Pell's shoulders lets go."),
        say("pip", "I thought..."),
        say("pip", "I thought if I didn't talk now, I'd have more left. For "
                   "later. For important things."),
        say("pip", "But then I'd never say anything. I'd just be saving forever."),
        say("pip", "Tomorrow I'll be careful. Today... today I'm going to be LOUD."),
        nar("And she is. She tells you about the snow, and the lake, and a dream "
            "she had, and the best soup she ever ate, and how much she loves Rue. "
            "All of it free. All of it hers."),
        understand("sollow"),
        note("sollow", "Pell decided to spend her last free day talking. Running "
                       "out of words isn't running out of things to say."),
    ]),
    E(when=("sollow_done",), steps=[
        say("pip", "I named my feather seventeen times today! All different names! "
                   "They were all FREE!"),
    ]),
    E(once="pell_intro", steps=[
        nar("A child stands at the frosted window holding a white feather. She "
            "looks at you with huge eyes, lips pressed tight."),
        you("Hi. What's your name?"),
        nar("She shakes her head hard, as if words were bees that might escape."),
        note("sollow", "Pell, a child, won't say a single word, even though her "
                       "words are still free."),
    ]),
    E(steps=[nar("Pell watches the snow. Her lips move once, then press shut again.")]),
]

DIALOGUE[("sollow", "dev")] = [
    E(once="devo_intro", steps=[
        nar("A teamaker pours steaming cups behind a stone counter. A sign above "
            "him reads, in careful letters: ONE CUP, ONE WORD."),
        nar("A customer approaches, thinks for a long while, and pays: 'Warm.' "
            "The teamaker bows as if he has been handed a gold coin."),
        nar("He pours you a cup and waves away your attempt to pay. Your words "
            "are free, so they're worthless here. You can't spend what costs nothing."),
        note("sollow", "At the teahouse, people pay for tea with one spoken word. "
                       "My words can't pay for anything; they're free."),
    ]),
    E(steps=[
        nar("Devo chalks on a slate: 'WRITING ISN'T COUNTED. BUT HERE, A WRITTEN "
            "WORD FEELS LIKE A FAKE COIN.' Below, today's payments: WARM. SNOW. "
            "MOTHER. YES."),
    ]),
]

DIALOGUE[("sollow", "hale")] = [
    E(once="hollis_intro", steps=[
        nar("A man in a fine, faded coat sits very straight. A small slate hangs "
            "around his neck. Chalked on it: 11."),
        nar("When he was young, they say, he was a great talker: a seller of "
            "anything to anyone. He spent his Count like water."),
        nar("He studies you for a long moment. Then, carefully, he spends one."),
        say("hale", "Welcome."),
        nar("He wipes the slate and chalks: 10."),
        note("sollow", "Hollis spent nearly his whole Count when he was young, "
                       "selling things. He has 10 words left."),
    ]),
    E(when=("sollow_done",), once="hollis_after", steps=[
        nar("Hollis has been listening to Pell chatter. He watches her for a long "
            "time. Then he spends another."),
        say("hale", "Good."),
        nar("The slate now reads 9. Somehow he looks richer than before."),
    ]),
    E(steps=[
        nar("Hollis gives you a small nod. He's saving the rest. You find yourself "
            "hoping he's saving them for someone."),
    ]),
]

# ================================ HESK ====================================

DIALOGUE[("hesk", "teodor")] = [
    E(once="teo_hesk", steps=[
        say("teodor", "Keep your voice down. In Hesk it's always the hour between "
                      "sleeping and waking."),
        say("teodor", "And here, everybody's dreams are everybody's business."),
    ]),
    E(steps=teodor_hint),
]

DIALOGUE[("hesk", "marisol")] = [
    E(when=("harlan_confessed", "!hesk_done"), once="mira_resolve", steps=[
        you("Mira, the box dream. It's Harlan's."),
        say("marisol", "I know. He came to me just now, shaking, and told me everything."),
        say("marisol", "He was so ashamed he stopped sleeping, so the dream "
                       "wouldn't get out. Of course it got out anyway. The whole "
                       "village has been falling with that box for weeks."),
        say("marisol", "Tonight we'll all dream it gently, together. By morning "
                       "it will be lighter. That's what dreams are for, here."),
        say("marisol", "You visitors keep everything inside, all alone. I honestly "
                       "don't know how you stand it."),
        flag("heard_nightmare"),
        understand("hesk"),
        note("hesk", "Once Harlan told the truth, the whole village could carry "
                     "it with him. A shared secret becomes lighter."),
    ]),
    E(once="mira_intro", steps=[
        nar("A woman sits at a candlelit altar, eyes heavy, sorting through "
            "sketches of last night's dream."),
        say("marisol", "Oh. A visitor. We can't see your dreams. How lonely that "
                       "must be for you."),
        say("marisol", "In Hesk the whole village dreams one dream together, every "
                       "night. I'm the Dream-Reader. Each morning I tell everyone "
                       "what it meant."),
        say("marisol", "Usually it's easy. Someone's in love, someone misses their "
                       "mother, someone ate too much plum cake. We know everything "
                       "about each other. There's no point pretending."),
        say("marisol", "But for weeks now we've all dreamed the same nightmare: a "
                       "locked box, falling down an endless stair. We wake up "
                       "exhausted. Nobody knows whose it is."),
        say("marisol", "A dream with no owner is a terrible thing. It's like a cry "
                       "from a room with no door."),
        flag("heard_nightmare"),
        note("hesk", "In Hesk the whole village shares one dream every night. "
                     "Nothing about anyone stays private."),
        note("hesk", "For weeks, everyone has dreamed of a locked box falling down "
                     "an endless stair. Nobody knows whose dream it is."),
    ]),
    E(when=("hesk_done",), steps=[
        say("marisol", "Last night we dreamed of bread, and a long road home, and "
                       "someone saying 'we'll figure it out.' Best dream we've had "
                       "all year."),
    ]),
    E(steps=[
        say("marisol", "Whose box is it? Someone's carrying something they won't "
                       "set down. I can feel it every night."),
    ]),
]

DIALOGUE[("hesk", "ruth")] = [
    E(once="ru_intro", steps=[
        nar("An old woman rocks in a hammock, knitting with her eyes closed."),
        say("ruth", "My husband died eleven years ago. I still dream about him "
                    "most nights."),
        say("ruth", "So the whole village dreams about him too. The children know "
                    "his laugh. The baker knows how he took his tea. None of them "
                    "ever met him."),
        say("ruth", "Everyone here misses him. Isn't that strange? Isn't that lovely?"),
        note("hesk", "Old Ru dreams of her late husband, so the whole village "
                     "misses him too, though most of them never met him."),
    ]),
    E(when=("heard_nightmare", "!hesk_done"), steps=[
        say("ruth", "When you share everything, grief gets divided and joy gets "
                    "multiplied. Nightmares, well. Those get multiplied too."),
        say("ruth", "The box dream started a few weeks ago. Right around when "
                    "someone came home."),
    ]),
    E(steps=[
        say("ruth", "Sleep well tonight, dear. We'll all be there."),
    ]),
]

DIALOGUE[("hesk", "pip")] = [
    E(once="pippa_intro", steps=[
        nar("A child holds a paper moth-lantern that glows softly. She studies "
            "you with open curiosity."),
        say("pip", "Are you the one with private dreams? Mira says visitors have "
                   "dreams nobody else can see."),
        say("pip", "Doesn't that get lonely? If you have a nightmare, who wakes "
                   "up with you?"),
        you("Nobody, I guess. You just wake up."),
        say("pip", "That's the saddest thing I ever heard."),
        note("hesk", "To the children of Hesk, dreaming alone sounds like the "
                     "loneliest thing in the world."),
    ]),
    E(when=("heard_nightmare", "!hesk_done"), once="pippa_hint", steps=[
        say("pip", "The box dream started when Harlan came back from the city. "
                   "Nobody's saying so. We don't say things until the dreamer's ready."),
        say("pip", "But everybody's thinking it."),
        note("hesk", "Pippa says the box dream started when Harlan came back "
                     "from the city."),
    ]),
    E(when=("hesk_done",), steps=[
        say("pip", "Last night's dream had BREAD in it. Big loaves. I ate four. "
                   "Everybody saw."),
    ]),
    E(steps=[say("pip", "If you dream about us tonight, we'll never even know. "
                        "That's so weird.")]),
]

DIALOGUE[("hesk", "dev")] = [
    E(once="deven_intro", steps=[
        nar("The baker pulls loaves from a glowing oven. Each one is shaped like "
            "something: a fish, a key, a cat."),
        say("dev", "Dream-bread. Every morning I bake whatever we all dreamed. It "
                   "helps people chew on it."),
        say("dev", "Lately it's been boxes. Box after box. Nobody wants to eat a box."),
        note("hesk", "Deven bakes bread shaped like last night's shared dream. "
                     "Lately: only boxes."),
    ]),
    E(when=("hesk_done",), steps=[
        say("dev", "Look: compass loaves! And long ones, shaped like roads. "
                   "Everyone's taking two."),
    ]),
    E(steps=[say("dev", "Box-bread again. Even the birds won't eat it.")]),
]


def _harlan_confession():
    return [
        nar("Harlan sits bolt upright, clutching a small locked box."),
        choice(
            ("Tell him about Mr. Hale", [
                you("I met a man in another place. He carries a box like yours. He "
                    "says everything's great, too. He hasn't slept either."),
                say("hale", "Another place..."),
                nar("Harlan looks down at the box. His hands are shaking."),
                say("hale", "The guild in the city sent me home. Twenty years "
                            "drawing maps for the high houses, and they sent me "
                            "home with this. My tools, in a box."),
                say("hale", "I couldn't bear for everyone to know. So I stopped "
                            "sleeping. I thought if I didn't dream, the box would "
                            "stay shut."),
                say("hale", "But I'd doze off for a moment, and there it was. "
                            "Falling. And the whole village falling after it."),
                say("hale", "I've been making all of them carry my shame without "
                            "even telling them it was mine."),
                you("Maybe they'd rather carry it knowing."),
                nar("Harlan stands, unsteady. He unlocks the box. Inside: pens, a "
                    "brass compass, a half-finished map of home."),
                say("hale", "I'm going to tell Mira. Then I'm going to sleep for a "
                            "very long time."),
                flag("harlan_confessed", "met_harlan"),
                note("hesk", "Harlan was sent home from the mapmakers' guild in "
                             "the city. He stopped sleeping to keep it secret, "
                             "but it leaked into everyone's dream."),
            ]),
            ("Leave him be", [
                say("hale", "Thank you. I'm fine. Really. Everything's great."),
            ]),
        ),
    ]


DIALOGUE[("hesk", "hale")] = [
    E(when=("hesk_done",), steps=[
        say("hale", "Slept fourteen hours. Everyone dreamed my failure, and in the "
                    "morning the baker made me a loaf shaped like a compass."),
        say("hale", "I've never felt so un-alone."),
    ]),
    E(when=("harlan_confessed",), steps=[
        say("hale", "I told Mira. She just held my hands. Go see her. I think she "
                    "wants to thank you."),
    ]),
    E(when=("hale_secret",), steps=_harlan_confession()),
    E(once="harlan_intro", steps=[
        nar("A man in rumpled nightclothes sits bolt upright, eyes red-rimmed, "
            "as though he's afraid to blink."),
        say("hale", "Evening. Or morning. I lose track."),
        you("You look tired."),
        say("hale", "Me? No, no. I'm fine. Sleeping great. Everything is great."),
        nar("He grips a small wooden box in his lap. It's locked."),
        flag("met_harlan"),
        note("hesk", "Harlan recently came back from the city. He insists "
                     "everything is 'great,' clutches a locked box, and won't sleep."),
    ]),
    E(steps=[
        say("hale", "Great. Everything's great."),
        nar("He blinks very slowly, then jerks himself awake."),
    ]),
]

# =============================== AMBRINE ==================================

DIALOGUE[("ambrine", "teodor")] = [
    E(once="teo_ambrine", steps=[
        say("teodor", "Mind your suitcase. Nobody will steal it. They'll feel "
                      "sorry for you."),
        say("teodor", "Here, carrying luggage is like wearing rags."),
    ]),
    E(steps=teodor_hint),
]


def _amarys_intro(s):
    steps = [
        nar("A woman sits behind a table piled with ledgers, writing with a long "
            "feathered pen. People call out gifts as they pass: 'Two pears to "
            "Oma!' 'My good boots to the boy at the well!' She writes each one down."),
    ]
    if "gave_cake" in s.flags:
        steps += [
            say("marisol", "Ah, the Burdened One who gave a lemon cake to Hollan! "
                           "You're already in the Ledger. Welcome."),
        ]
    else:
        steps += [
            say("marisol", "A Burdened one! Look at you, dragging all your things "
                           "behind you. You poor creature."),
        ]
    steps += [
        say("marisol", "This is the Great Ledger. Every gift in Ambrine is written "
                       "here: who gave, what, and to whom."),
        say("marisol", "Here, nobody owns. Keeping a thing past one season is "
                       "shameful. Whatever you've held too long, you give away at "
                       "the Giving. That's tomorrow."),
        say("marisol", "Whoever has given the most is the most honored. Our most "
                       "honored citizen owns one shirt, and he didn't own it yesterday."),
    ]
    if "gave_cake" not in s.flags:
        steps += [
            say("marisol", "You, though, aren't in the Ledger. You've given nothing. "
                           "Forgive me, but here that means you aren't anyone yet."),
            note("ambrine", "Until you give a gift, you aren't in the Ledger, and "
                            "you aren't quite anyone."),
        ]
    steps += [
        flag("know_ledger"),
        note("ambrine", "In Ambrine, nobody owns anything for long. Honor comes "
                        "from giving."),
        note("ambrine", "Anything kept longer than a season must be given away "
                        "at the Giving."),
        note("ambrine", "Travelers who arrive with luggage are called 'the "
                        "Burdened,' and pitied."),
    ]
    return steps


DIALOGUE[("ambrine", "marisol")] = [
    E(when=("ambrine_done",), once="amarys_laugh", steps=[
        say("marisol", "Let me read you today's lines. 'Pim gave her carved bird "
                       "to the Stranger.' And then: 'The Stranger gave a carved "
                       "bird to Pim.'"),
        nar("She laughs so hard she has to put down her pen."),
        say("marisol", "Oh, that's the oldest trick in Ambrine. Every child finds "
                       "it eventually. I did it with a blue ribbon when I was eight."),
        say("marisol", "Don't look worried. It isn't cheating. It's the whole point. "
                       "Things aren't meant to stop with anyone. They're meant to "
                       "move, even if they only move in a circle."),
        note("ambrine", "Amarys: 'Things aren't meant to stop with anyone. They're "
                        "meant to move, even if they only move in a circle.'"),
    ]),
    E(once="amarys_intro", steps=_amarys_intro),
    E(when=("gave_cake", "!ambrine_done"), once="amarys_cake", steps=[
        say("marisol", "There you are, in the Ledger! 'The Burdened One gave a lemon "
                       "cake to Hollan.' Your very first line. Welcome to Ambrine."),
    ]),
    E(when=("has:lemon cake", "!gave_cake"), steps=[
        say("marisol", "Something from your world? How exciting. But gifts aren't "
                       "given to the Ledger, dear. Find whoever has the least. "
                       "That's where strangers usually start."),
    ]),
    E(steps=[
        say("marisol", "Six plums to the twins! Sorry. Busy day. Everyone's "
                       "getting ready for the Giving."),
    ]),
]

DIALOGUE[("ambrine", "ruth")] = [
    E(once="gm_intro", steps=[
        nar("An old woman sits barefoot on a woven mat, knitting with borrowed yarn."),
        say("ruth", "Hello, dear. No, I don't have a name anymore. I gave it to my "
                    "granddaughter last spring. She wears it better."),
        say("ruth", "So now I'm just Grandmother. It's a good name. Lots of people "
                    "have had it."),
        note("ambrine", "Grandmother gave her own name to her granddaughter. Now "
                        "she's just 'Grandmother.'"),
    ]),
    E(once="gm_hands", steps=[
        say("ruth", "Giving is easy, once you get the knack. Receiving is the hard art."),
        say("ruth", "A gift needs two hands, dear: one to let go, and one to take "
                    "hold. Whoever takes is giving something too. They give the "
                    "other person the chance to be generous."),
        note("ambrine", "Grandmother: 'A gift needs two hands. Whoever takes is "
                        "giving something too.'"),
    ]),
    E(when=("ambrine_done",), steps=[
        say("ruth", "That bird has gone around twice now. It'll be the most "
                    "honored bird in Ambrine."),
    ]),
    E(steps=[
        say("ruth", "The yarn's borrowed. The needles were a gift. The scarf is "
                    "for whoever gets cold first."),
    ]),
]


def _pim_offer():
    return choice(
        ("Take the bird", [
            nar("Pim sets the bird in your palm. Her hands hover over it for a "
                "moment. Then they let go."),
            say("pip", "Bye, bird."),
            give("carved bird"),
            note("ambrine", "Pim gave me her carved bird. It looked like it cost "
                            "her everything."),
        ]),
        ("Tell her to just keep it", [
            you("Why not just keep it? It's yours. Nobody should make you give it up."),
            nar("Pim stares at you, horrified."),
            say("pip", "Keep it? Like a... like a Burdened? Everyone would know."),
            say("pip", "You don't understand anything."),
            nar("She turns away. Maybe the answer here isn't the one you'd give at home."),
            note("ambrine", "I told Pim to just keep her bird. She was horrified. "
                            "In Ambrine, keeping isn't kindness."),
        ]),
    )


DIALOGUE[("ambrine", "pip")] = [
    E(when=("has:carved bird",), steps=[
        say("pip", "Did you decide who gets my bird?"),
        choice(
            ("Give the bird to Pim", [
                you("Pim, I'd like to give you something."),
                nar("You hold out the carved bird."),
                nar("Pim stares at it. Then at you. Then a slow, enormous grin "
                    "spreads across her face."),
                say("pip", "You're giving it to ME? Then it's a new gift. From a "
                           "Stranger. That's not keeping. That's RECEIVING."),
                say("pip", "I get to hold it a whole new season!"),
                nar("Across the plaza, the Ledger writes two lines in the Great "
                    "Ledger and begins to laugh."),
                take("carved bird"),
                understand("ambrine"),
                note("ambrine", "I gave the bird back to Pim. A returned gift is a "
                                "new gift, so she can hold it another season."),
            ]),
            ("Not yet", [
                say("pip", "Okay. Whoever gets it is really lucky."),
            ]),
        ),
    ]),
    E(when=("ambrine_done",), steps=[
        say("pip", "Me and Bird have a whole new season! Grandpa would think it's "
                   "funny. He did the same trick with Grandmother's ring."),
    ]),
    E(when=("gave_cake", "!seen:pim_open"), once="pim_open", steps=[
        say("pip", "You gave Hollan a cake! Everybody's talking about it. So you're "
                   "someone now."),
        nar("She opens her hands. The carved bird is worn smooth, its painted eye "
            "almost rubbed away."),
        say("pip", "My grandpa carved it. I've had it for three whole seasons. "
                   "That's really long. That's shameful."),
        say("pip", "Tomorrow's the Giving. I have to give it away. Everyone knows "
                   "I've had it too long."),
        say("pip", "I don't want it to go to somebody who won't love it. Will you "
                   "take it? You're a Stranger-Who-Gives now."),
        flag("pim_asked"),
        _pim_offer(),
    ]),
    E(when=("pim_asked",), steps=[
        say("pip", "Will you take my bird? Please?"),
        _pim_offer(),
    ]),
    E(once="pim_intro", steps=[
        nar("A child sits with her back to you, hunched over something in her lap."),
        say("pip", "Mama says not to talk to the Burdened. Sorry. You're not in the Ledger."),
        nar("Before she turns away, you glimpse a carved wooden bird, worn smooth "
            "from holding."),
        note("ambrine", "Pim won't talk to anyone who isn't in the Ledger. She's "
                        "hiding a carved wooden bird."),
    ]),
    E(steps=[say("pip", "Sorry. You're still not in the Ledger.")]),
]


def _bread_choice(first):
    accept = [
        nar("You take it. It's still warm. You eat it right there, and Dov beams."),
        say("dev", "Ah! Thank you. You have honored me."),
        flag("accepted_bread"),
        note("ambrine", "When I accepted Dov's bread, he thanked ME. Receiving "
                        "honors the giver."),
    ]
    decline = [
        you("Oh, no thank you, I couldn't."),
        nar("Dov's face falls. People nearby stop and stare, as if you'd slapped him."),
        say("dev", "You... refuse my gift?"),
        say("dev", "Do I have so little honor that even a Burdened won't take from me?"),
        flag("refused_bread"),
        note("ambrine", "I politely refused Dov's bread. In Ambrine, refusing a "
                        "gift is an insult: it denies the giver their honor."),
    ]
    if first:
        return choice(("Accept the bread", accept), ("Politely decline", decline))
    return choice(("Accept the bread this time", accept),
                  ("Walk away", [nar("Dov turns back to his loaves, stiffly.")]))


DIALOGUE[("ambrine", "dev")] = [
    E(once="dov_intro", steps=[
        nar("A man stands behind a long table of fresh loaves, handing them to "
            "everyone who passes. Nobody pays. Nobody is expected to."),
        say("dev", "You look hungry, Burdened one. Here, take a loaf."),
        _bread_choice(True),
    ]),
    E(when=("refused_bread", "!accepted_bread"), steps=[
        say("dev", "Come to refuse me again?"),
        _bread_choice(False),
    ]),
    E(steps=[
        say("dev", "Bread for everyone! Tomorrow at the Giving I'll give away the "
                   "oven itself. Then I'll bake in somebody else's."),
    ]),
]


def _hollan_give():
    return choice(
        ("Give Hollan the lemon cake", [
            nar("You hold out the lemon cake. Hollan takes it in both hands, as "
                "carefully as if it were glass."),
            say("hale", "From another world entirely! Oh, this is a fine gift. "
                        "Thank you. Thank you."),
            nar("He breaks it into pieces and hands them to everyone nearby. Within "
                "a minute the whole plaza smells of lemons."),
            nar("Somewhere, a pen scratches in the Great Ledger."),
            take("lemon cake"),
            flag("gave_cake"),
            toast("You are now in the Ledger"),
            note("ambrine", "I gave Hollan the lemon cake from Gate 14. He shared "
                            "it with everyone. Now I'm in the Ledger."),
        ]),
        ("Not yet", [say("hale", "Of course. Hold it as long as you need.")]),
    )


def _hollan_intro(s):
    steps = [
        nar("A man in one plain shirt sits on the bare ground, utterly serene. "
            "People bow a little as they pass him."),
        say("hale", "Welcome. I am Hollan. They call me the Poorest Man in Ambrine. "
                    "It is the highest title we have."),
        say("hale", "Once I was the richest merchant on the coast. Ships, "
                    "warehouses, a house with forty doors. It took me thirty "
                    "years to give it all away."),
        say("hale", "This shirt was a gift this morning. Tomorrow I'll give it to "
                    "someone colder."),
        note("ambrine", "Hollan, the Poorest Man, is the most honored person in "
                        "Ambrine. He used to be the richest."),
    ]
    if "lemon cake" in s.items and "gave_cake" not in s.flags:
        steps += [say("hale", "And you carry something that smells of lemons."), _hollan_give()]
    return steps


DIALOGUE[("ambrine", "hale")] = [
    E(once="hollan_intro", steps=_hollan_intro),
    E(when=("has:lemon cake", "!gave_cake"), steps=[
        say("hale", "You carry something that smells of lemons."),
        _hollan_give(),
    ]),
    E(when=("gave_cake",), steps=[
        say("hale", "The cake was delicious. I gave most of it away, of course. "
                    "That's what made it delicious."),
    ]),
    E(steps=[say("hale", "Give something, and you'll see. It is lighter than it sounds.")]),
]

# --------------------------------------------------------------------------
# Things to look at
# --------------------------------------------------------------------------

OBJECTS = {
    "home": {
        "K": ("Departures board", [
            E(when=("all_done",), steps=[nar("1407 PORTLAND: BOARDING. The word is "
                                             "green. It looks almost embarrassed.")]),
            E(steps=[nar("DEPARTURES. 1407 PORTLAND: DELAYED. The word blinks "
                         "patiently, like it has all the time in the world. It does.")]),
        ]),
        "W": ("Window", [E(steps=[nar("Rain on the runway. A plane is being de-iced, "
                                      "slowly, like a large patient animal getting a bath.")])]),
        "F": ("Information kiosk", [E(steps=[nar("An information kiosk. The screen asks: "
                                                 "HOW CAN WE HELP? Nobody has touched it "
                                                 "in years. It keeps asking.")])]),
        "G": ("Jet bridge door", [
            E(when=("all_done",), steps=[nar("The door is unlocked now. Cold air, jet "
                                             "fuel, the hum of engines. Talk to Marisol "
                                             "to board.")]),
            E(steps=[nar("The door to the jet bridge. Locked. A laminated sign says GATE "
                         "14, in case you'd forgotten. You hadn't.")]),
        ]),
        "P": ("Potted plant", [E(steps=[nar("A plastic ficus. Someone has watered it "
                                            "anyway. You find that you respect them.")])]),
        "B": ("Seats", [E(steps=[nar("A row of seats with armrests placed precisely to "
                                     "stop anyone from lying down. Someone designed "
                                     "this. Someone was proud of it.")])]),
        "C": ("Café counter", [E(steps=[nar("A pastry case: two lonely muffins and a "
                                            "sign that says FRESH TODAY. It does not "
                                            "say which day.")])]),
        "D": ("Gate desk", [E(steps=[nar("A sticker on the desk: THANK YOU FOR YOUR "
                                         "PATIENCE. You have given it a great deal.")])]),
    },
    "sollow": {
        "K": ("Wall of Counts", [
            E(when=("sollow_done",), steps=[
                nar("The Wall of Counts. Every name in Sollow, carved beside a number."),
                nar("Beneath the blank space for PELL, someone has left a smooth white "
                    "stone: a gift of silence, for luck."),
            ]),
            E(steps=[
                nar("The Wall of Counts. Every name in Sollow is carved here beside a "
                    "number. Some numbers are vast. Some are heartbreakingly small."),
                nar("Beside RUE, the number has been rubbed down to 0 by many "
                    "fingers. Touching it is supposed to be lucky."),
                nar("Beside PELL, the stone is still blank. Tomorrow it will be carved."),
                note("sollow", "The Wall of Counts lists every name in Sollow and "
                               "how many words each person was given."),
            ]),
        ]),
        "W": ("Window", [E(steps=[nar("Outside: a frozen lake under a white sky. "
                                      "Nothing moves. Even the wind seems to be saving "
                                      "its breath.")])]),
        "F": ("The Silent Well", [E(steps=[
            nar("The Silent Well. Sollowans come here to whisper, into the dark, "
                "the words they can't afford to spend."),
            nar("Words the well swallows are never heard, so they never count. Every "
                "culture finds a loophole somewhere."),
            note("sollow", "At the Silent Well, people whisper words no one hears. "
                           "Those words don't count."),
        ])]),
        "G": ("Archway", [E(steps=[nar("An archway onto endless snowfields. A line of "
                                       "footprints leads out, unhurried, and doesn't "
                                       "come back.")])]),
        "P": ("Birch tree", [E(steps=[
            nar("A silver birch hung with hundreds of small wooden tags. Each has a "
                "single word carved into it: MOTHER. SORRY. YES. HERE."),
            nar("People hang one here whenever a word was truly worth spending."),
            note("sollow", "The birch tree is hung with tags, one word each, for "
                           "words that were worth spending."),
        ])]),
        "B": ("Stone bench", [E(steps=[nar("A stone bench softened with sheepskins. It's "
                                           "very quiet here. Not empty. Quiet. You're "
                                           "starting to feel the difference.")])]),
        "C": ("Tea counter", [E(steps=[nar("Steam curls off a black iron kettle. The "
                                           "cups are tiny, as if tea here is meant to "
                                           "be taken one word at a time.")])]),
        "D": ("The Book of Counts", [E(steps=[nar("The Book of Counts lies open. The "
                                                  "handwriting is very small. In Sollow, "
                                                  "even ink is careful.")])]),
    },
    "hesk": {
        "K": ("Dream Mural", [
            E(when=("hesk_done",), steps=[nar("Fresh paint over the old: the box is "
                                              "open. Inside are a compass and a loaf "
                                              "of bread, and out of it runs a long "
                                              "road home.")]),
            E(steps=[
                nar("The Dream Mural. Each dawn the villagers paint last night's "
                    "shared dream here, together."),
                nar("For weeks it's been the same picture, painted over and over: a "
                    "locked box, tumbling down an endless stair."),
                note("hesk", "Every dawn the village paints its shared dream on the "
                             "Dream Mural. For weeks: a falling box."),
            ]),
        ]),
        "W": ("Window", [E(steps=[nar("Two moons hang in a violet sky. In Hesk it is "
                                      "always the soft hour between sleeping and waking.")])]),
        "F": ("The Still Pool", [E(steps=[
            nar("The Still Pool. Heskans come here to look at their own reflection: "
                "the one thing in Hesk that belongs to only one person."),
            note("hesk", "The Still Pool shows your reflection, the only truly "
                         "private thing a Heskan has."),
        ])]),
        "G": ("Moon gate", [E(steps=[nar("A round moon-gate. Through it you can see "
                                         "the village rooftops: every window dark, "
                                         "everyone inside dreaming the same thing at "
                                         "the same time.")])]),
        "P": ("Glowing mushrooms", [E(steps=[nar("A cluster of glowing mushrooms "
                                                 "pulses slowly, as if it's breathing "
                                                 "in its sleep.")])]),
        "B": ("Hammocks", [E(steps=[nar("Hammocks strung between posts. Two villagers "
                                        "doze in them, and smile in their sleep at "
                                        "exactly the same moment.")])]),
        "C": ("Oven", [
            E(when=("hesk_done",), steps=[nar("A tray of compass-shaped loaves. Half "
                                              "of them are already gone.")]),
            E(steps=[nar("The oven glows like a small sun. A tray of box-shaped loaves "
                         "cools on the counter, untouched.")]),
        ]),
        "D": ("Dream altar", [E(steps=[nar("Candles, and stacks of hurried sketches "
                                           "from people who woke up and drew before "
                                           "the dream could fade.")])]),
    },
    "ambrine": {
        "K": ("Giving Wall", [E(steps=[
            nar("The Giving Wall: thousands of ribbons, each one tied by someone who "
                "received a gift. Tomorrow is the Giving. The wall is nearly full."),
            note("ambrine", "Each ribbon on the Giving Wall marks a gift received. "
                            "Receiving is celebrated as much as giving."),
        ])]),
        "W": ("Market", [E(steps=[nar("Striped awnings snap in the warm wind. Beneath "
                                      "them is a market with no prices and no coins, "
                                      "only people handing things to each other.")])]),
        "F": ("Fountain", [E(steps=[
            nar("A fountain glittering with coins. Ambrinians toss them in not for "
                "wishes, but because a coin in a fountain belongs to no one, and so "
                "to everyone."),
            note("ambrine", "Coins in the fountain belong to no one, and so to everyone."),
        ])]),
        "G": ("Archway", [E(steps=[nar("A sunlit archway. People pass through carrying "
                                       "nothing at all, swinging their empty hands "
                                       "like it's the most natural thing in the world.")])]),
        "P": ("Fig tree", [E(steps=[nar("A fig tree, heavy with fruit. A painted sign "
                                        "reads: TAKE ONE. SOMEONE GAVE THIS TO YOU.")])]),
        "B": ("Gift baskets", [E(steps=[nar("Baskets of things waiting to be given away "
                                            "tomorrow: shoes, cups, a kite, a single "
                                            "excellent spoon.")])]),
        "C": ("Bread table", [E(steps=[nar("Loaves and loaves. Nobody guards them. "
                                           "Nobody needs to.")])]),
        "D": ("The Great Ledger", [E(steps=[nar("The Great Ledger. Every gift in Ambrine, "
                                                "going back four hundred years. It's the "
                                                "only thing here nobody gives away.")])]),
    },
}
