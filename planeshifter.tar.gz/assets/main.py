#!/usr/bin/env python3
"""
Plane Shifter
A short narrative game inspired by Ursula K. Le Guin's "Changing Planes".

Run:  python main.py            (add --fullscreen for presenting,
                                  --skip-intro to jump straight in)
"""

import asyncio
import math
import os
import random
import sys

os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")
import pygame

import art
import story
from audio import Audio

W, H = 960, 640
TILE = art.TILE
COLS, ROWS = art.COLS, art.ROWS
MAP_W, MAP_H = art.MAP_W, art.MAP_H
FPS = 60
SPEED = 140
PLANES = story.PLANES
INFO = story.PLANE_INFO

INK = (236, 232, 222)
DIM = (150, 150, 162)
PAPER = (238, 230, 212)
PAPER_INK = (52, 44, 40)

SERIF = ["georgia", "palatino", "timesnewroman", "times"]
SANS = ["avenirnext", "avenir", "helveticaneue", "helvetica", "arial"]
MONO = ["menlo", "monaco", "couriernew"]


# --------------------------------------------------------------------------
# Text helpers
# --------------------------------------------------------------------------

def load_font(names, size, bold=False, italic=False):
    for n in names:
        path = pygame.font.match_font(n, bold=bold, italic=italic)
        if path:
            try:
                return pygame.font.Font(path, size)
            except (OSError, pygame.error):
                continue
    f = pygame.font.Font(None, int(size * 1.3))
    f.set_bold(bold)
    f.set_italic(italic)
    return f


_wrap_cache = {}


def wrap(font, text, width):
    key = (id(font), text, width)
    if key in _wrap_cache:
        return _wrap_cache[key]
    lines = []
    for para in text.split("\n"):
        cur = ""
        for word in para.split(" "):
            test = word if not cur else cur + " " + word
            if font.size(test)[0] <= width:
                cur = test
            else:
                if cur:
                    lines.append(cur)
                cur = word
        lines.append(cur)
    _wrap_cache[key] = lines
    return lines


def text(surf, font, s, color, pos, anchor="topleft", alpha=255, shadow=False):
    img = font.render(s, True, color)
    if alpha < 255:
        img.set_alpha(alpha)
    r = img.get_rect(**{anchor: pos})
    if shadow:
        sh = font.render(s, True, (0, 0, 0))
        sh.set_alpha(int(alpha * 0.6))
        surf.blit(sh, r.move(2, 2))
    surf.blit(img, r)
    return r


def panel(surf, rect, color=(14, 14, 22), alpha=232, border=None, radius=12, width=2):
    rect = pygame.Rect(rect)
    s = pygame.Surface(rect.size, pygame.SRCALPHA)
    pygame.draw.rect(s, (*color, alpha), s.get_rect(), border_radius=radius)
    if border:
        pygame.draw.rect(s, (*border, 255), s.get_rect(), width, border_radius=radius)
    surf.blit(s, rect.topleft)


def dim(surf, alpha=150, color=(0, 0, 0)):
    s = pygame.Surface(surf.get_size(), pygame.SRCALPHA)
    s.fill((*color, alpha))
    surf.blit(s, (0, 0))


def diamond(surf, center, size, color, filled):
    x, y = center
    pts = [(x, y - size), (x + size, y), (x, y + size), (x - size, y)]
    if filled:
        pygame.draw.polygon(surf, color, pts)
    pygame.draw.polygon(surf, color if filled else (110, 110, 120), pts, 2)


def keycap(surf, font, label, pos, color=(60, 60, 72)):
    w = max(22, font.size(label)[0] + 12)
    r = pygame.Rect(pos[0], pos[1], w, 20)
    pygame.draw.rect(surf, color, r, border_radius=5)
    pygame.draw.rect(surf, (110, 110, 126), r, 1, border_radius=5)
    text(surf, font, label, INK, r.center, "center")
    return r


# --------------------------------------------------------------------------
# World objects
# --------------------------------------------------------------------------

class State:
    def __init__(self):
        self.flags = set()
        self.items = []
        self.seen = set()
        self.notes = {p: [] for p in PLANES}
        self.understood = []
        self.visited = {"home"}
        self.met = set()
        self.plane = "home"


class NPC:
    def __init__(self, nid, data):
        self.id = nid
        self.data = data
        tx, ty = data["pos"]
        self.bx, self.by = tx * TILE + 16, ty * TILE + 26
        self.x, self.y = self.bx, self.by
        self.home_x = self.bx
        self.phase = random.uniform(0, 6)
        self.facing = (0, 1)
        self.moving = False
        self.walk = 0.0
        self.dir = 1
        self.wait = 0.0

    def place(self, plane):
        self.x = self.home_x if plane in self.data.get("pace", {}) else self.bx
        self.y = self.by

    def look(self, plane):
        return self.data["looks"][plane]

    def name(self, plane):
        return self.data["names"][plane]

    def role(self, plane):
        return self.data["roles"][plane]

    def seated(self, plane):
        return self.data.get("seated", False) or plane in self.data.get("seated_in", ())

    def rect(self):
        return pygame.Rect(int(self.x) - 9, int(self.y) - 9, 18, 10)


class Player:
    def __init__(self, tx, ty):
        self.x, self.y = tx * TILE + 16, ty * TILE + 26
        self.facing = (0, 1)
        self.moving = False
        self.walk = 0.0

    def rect_at(self, x, y):
        return pygame.Rect(int(x) - 8, int(y) - 8, 16, 9)


class Dialogue:
    """Plays a list of story steps, one box at a time."""

    CPS = 70  # characters per second

    def __init__(self, game, steps, npc=None, title=None):
        self.g = game
        self.queue = list(steps)
        self.npc = npc
        self.title = title
        self.cur = None
        self.shown = 0.0
        self.sel = 0
        self.done = False
        self.next()

    def next(self):
        while self.queue:
            st = self.queue.pop(0)
            if st[0] in ("say", "nar"):
                self.cur, self.shown = st, 0.0
                return
            if st[0] == "choice":
                self.cur, self.sel = st, 0
                self.g.audio.play("tick", 0.6)
                return
            self.g.apply(st)
        self.cur = None
        self.done = True

    @property
    def is_choice(self):
        return self.cur is not None and self.cur[0] == "choice"

    def line(self):
        return self.cur[2] if self.cur[0] == "say" else self.cur[1]

    def full(self):
        return self.cur is None or self.is_choice or self.shown >= len(self.line())

    def update(self, dt):
        if self.cur and not self.full():
            before = int(self.shown)
            self.shown += dt * self.CPS
            if self.cur[0] == "say" and before // 3 != int(self.shown) // 3:
                self.g.audio.play("blip", 0.35)

    def press(self):
        if self.cur is None:
            return
        if self.is_choice:
            self.choose(self.sel)
        elif not self.full():
            self.shown = len(self.line())
        else:
            self.next()

    def choose(self, i):
        options = self.cur[1]
        if 0 <= i < len(options):
            self.g.audio.play("tick", 0.6)
            self.queue = list(options[i][1]) + self.queue
            self.next()


# --------------------------------------------------------------------------
# The game
# --------------------------------------------------------------------------

class Game:
    def __init__(self, skip_intro=False, fullscreen=False):
        pygame.mixer.pre_init(44100, -16, 2, 512)
        pygame.init()
        pygame.display.set_caption("Plane Shifter")
        flags = pygame.SCALED | pygame.RESIZABLE
        if fullscreen:
            flags |= pygame.FULLSCREEN
        try:
            self.screen = pygame.display.set_mode((W, H), flags, vsync=1)
        except pygame.error:
            self.screen = pygame.display.set_mode((W, H))
        self.clock = pygame.time.Clock()
        self.fonts = {
            "title": load_font(SERIF, 66),
            "h1": load_font(SERIF, 38),
            "h2": load_font(SERIF, 22, bold=True),
            "body": load_font(SERIF, 20),
            "italic": load_font(SERIF, 20, italic=True),
            "slide": load_font(SERIF, 27),
            "journal": load_font(SERIF, 17),
            "journal_i": load_font(SERIF, 17, italic=True),
            "ui": load_font(SANS, 15),
            "ui_b": load_font(SANS, 15, bold=True),
            "ui_s": load_font(SANS, 13),
            "tiny": load_font(SANS, 10, bold=True),
            "mono": load_font(MONO, 10),
        }
        self.audio = Audio()
        self.features = art.feature_rects(story.LAYOUT)
        self.statics = {p: art.build_static(p, story.LAYOUT, self.features, self.fonts) for p in PLANES}
        self.thumbs = {p: pygame.transform.smoothscale(self.statics[p], (176, 106)) for p in PLANES}
        self.scenery = art.Scenery(self.features)
        self.vignette = art.make_vignette((MAP_W, MAP_H), 130)
        self.darkness = art.Darkness()
        self.world = pygame.Surface((MAP_W, MAP_H))
        self.wave = pygame.Surface((MAP_W, MAP_H))
        self.wave.set_colorkey((255, 0, 255))
        self.t = 0.0
        self.skip_intro = skip_intro
        self.running = True
        self.fx = None
        self.scene = "title"
        self.scene_t = 0.0
        self.slide = 0
        self.slides = []
        self.reset()
        self.audio.set_plane("hesk")

    # ---- setup ---------------------------------------------------------------
    def reset(self):
        self.state = State()
        self.npcs = [NPC(nid, d) for nid, d in story.NPCS.items()]
        self.player = Player(*story.PLAYER_START)
        self.suitcase = [self.player.x + 12, self.player.y]
        self.particles = art.Particles("home")
        self.mode = "walk"
        self.dialogue = None
        self.toasts = []
        self.pending_cards = []
        self.card_t = 0.0
        self.end_requested = False
        self.arrival = None
        self.transition = None
        self.dial_sel = 0
        self.journal_tab = 0
        self.journal_scroll = 0
        self.journal_flash = 0.0
        self.target = None

    def start_play(self):
        self.reset()
        self.scene = "play"
        self.audio.set_plane("home")
        self.arrival = {"plane": "home", "t": 0.0}
        self.toast("Move: arrow keys or WASD      Talk / look: E", sound=False)
        self.toast("Someone at this gate seems to know something.", sound=False, unless="can_shift")

    def start_ending(self):
        self.scene = "ending"
        self.slides = story.ending_slides(self.state) + ["__credits__"]
        self.slide = 0
        self.scene_t = 0.0
        self.audio.set_plane("ambrine")

    def fade(self, callback):
        if self.fx is None:
            self.fx = {"phase": "out", "t": 0.0, "cb": callback}

    # ---- story plumbing -------------------------------------------------------
    def check(self, conds):
        s = self.state
        for c in conds:
            neg = c.startswith("!")
            c = c[1:] if neg else c
            if c.startswith("has:"):
                v = c[4:] in s.items
            elif c.startswith("seen:"):
                v = c[5:] in s.seen
            elif c.startswith("visited:"):
                v = c[8:] in s.visited
            else:
                v = c in s.flags
            if v == neg:
                return False
        return True

    def pick(self, entries):
        s = self.state
        for e in entries:
            if e["once"] and e["once"] in s.seen:
                continue
            if self.check(e["when"]):
                if e["once"]:
                    s.seen.add(e["once"])
                steps = e["steps"]
                return steps(s) if callable(steps) else steps
        return [("nar", "...")]

    def apply(self, st):
        s = self.state
        kind = st[0]
        if kind == "set":
            s.flags.update(st[1])
        elif kind == "note":
            plane, line = st[1], st[2]
            if line not in s.notes[plane]:
                s.notes[plane].append(line)
                self.journal_flash = 4.0
        elif kind == "give":
            s.items.append(st[1])
            self.toast(f"Received: {st[1]}")
        elif kind == "take":
            if st[1] in s.items:
                s.items.remove(st[1])
            self.toast(f"Gave away: {st[1]}")
        elif kind == "understand":
            plane = st[1]
            if plane not in s.understood:
                s.understood.append(plane)
                s.flags.update({f"{plane}_done", "any_done"})
                if len(s.understood) >= len(story.STORY_PLANES):
                    s.flags.add("all_done")
                self.pending_cards.append(plane)
        elif kind == "toast":
            self.toast(st[1])
        elif kind == "end":
            self.end_requested = True

    def toast(self, msg, sound=True, unless=None):
        if len(self.toasts) >= 3:
            self.toasts.pop(1)
        self.toasts.append({"text": msg, "t": 0.0, "unless": unless})
        if sound:
            self.audio.play("pop", 0.7)

    # ---- dialogue & interaction -----------------------------------------------
    def open_dialogue(self, steps, npc=None, title=None):
        self.dialogue = Dialogue(self, steps, npc, title)
        if self.dialogue.done:
            self.close_dialogue()
        else:
            self.mode = "dialogue"

    def close_dialogue(self):
        self.dialogue = None
        self.mode = "walk"
        if self.pending_cards:
            self.mode = "card"
            self.card_t = 0.0
            self.audio.play("chime", 0.8)
        elif self.end_requested:
            self.fade(self.start_ending)

    def dismiss_card(self):
        plane = self.pending_cards.pop(0)
        if self.pending_cards:
            self.card_t = 0.0
            return
        self.mode = "walk"
        if "all_done" in self.state.flags and plane == self.state.understood[-1]:
            self.toast("Somewhere, a departures board flickers. Return to Gate 14.")
        if self.end_requested:
            self.fade(self.start_ending)

    def find_target(self):
        p = self.player
        plane = self.state.plane
        best, bd = None, 80
        for n in self.npcs:
            d = math.hypot(n.x - p.x, n.y - p.y)
            if d < bd:
                best, bd = ("npc", n), d
        if best:
            return best
        fx, fy = p.facing
        for dist in (18, 30):
            tx = int((p.x + fx * dist) // TILE)
            ty = int((p.y - 6 + fy * dist) // TILE)
            if 0 <= ty < ROWS and 0 <= tx < COLS:
                ch = story.LAYOUT[ty][tx]
                if ch in story.OBJECTS[plane]:
                    return ("obj", ch, (tx, ty))
        return None

    def interact(self):
        tgt = self.find_target()
        if not tgt:
            return
        plane = self.state.plane
        if tgt[0] == "npc":
            n = tgt[1]
            key = (plane, n.id)
            steps = self.pick(story.DIALOGUE[key])
            self.state.met.add(key)
            self.open_dialogue(steps, npc=n)
        else:
            label, entries = story.OBJECTS[plane][tgt[1]]
            self.open_dialogue(self.pick(entries), title=label)

    # ---- plane shifting ---------------------------------------------------------
    def open_dial(self):
        if "can_shift" not in self.state.flags:
            self.toast("You feel loose at the edges, but you don't know how to turn. Maybe someone here knows.")
            return
        self.mode = "dial"
        self.dial_sel = PLANES.index(self.state.plane)
        self.audio.play("tick", 0.6)

    def shift_to(self, plane):
        if plane == self.state.plane:
            self.mode = "walk"
            return
        old = pygame.Surface((MAP_W, MAP_H))
        self.draw_world(old)
        s = self.state
        s.plane = plane
        s.visited.add(plane)
        for n in self.npcs:
            n.place(plane)
        self.particles = art.Particles(plane, seed=random.randint(0, 999))
        self.nudge_player()
        new = pygame.Surface((MAP_W, MAP_H))
        self.draw_world(new)
        self.transition = {"old": old, "new": new, "t": 0.0, "dur": 1.15}
        self.mode = "transition"
        self.audio.play("shift", 0.8)
        self.audio.set_plane(plane)
        self.arrival = {"plane": plane, "t": -0.6}

    # ---- collision ------------------------------------------------------------
    def blocked(self, r, ignore=None):
        for ty in range(r.top // TILE, (r.bottom - 1) // TILE + 1):
            for tx in range(r.left // TILE, (r.right - 1) // TILE + 1):
                if not (0 <= ty < ROWS and 0 <= tx < COLS) or story.LAYOUT[ty][tx] != ".":
                    return True
        for n in self.npcs:
            if n is not ignore and n.rect().colliderect(r):
                return True
        return False

    def nudge_player(self):
        p = self.player
        if not self.blocked(p.rect_at(p.x, p.y)):
            return
        for radius in range(8, 160, 8):
            for k in range(16):
                a = k / 16 * math.tau
                x, y = p.x + math.cos(a) * radius, p.y + math.sin(a) * radius
                if not self.blocked(p.rect_at(x, y)):
                    p.x, p.y = x, y
                    return

    # ---- update ---------------------------------------------------------------
    def update(self, dt):
        self.t += dt
        self.scene_t += dt
        self.audio.update()
        if self.fx:
            self.fx["t"] += dt
            if self.fx["phase"] == "out" and self.fx["t"] >= 0.8:
                self.fx["cb"]()
                self.fx = {"phase": "in", "t": 0.0, "cb": None}
            elif self.fx["phase"] == "in" and self.fx["t"] >= 0.8:
                self.fx = None
        if self.scene != "play":
            return
        while self.toasts and self.toasts[0]["unless"] in self.state.flags:
            self.toasts.pop(0)
        if self.toasts:
            self.toasts[0]["t"] += dt
            if self.toasts[0]["t"] > self.toast_life():
                self.toasts.pop(0)
        self.journal_flash = max(0.0, self.journal_flash - dt)
        if self.arrival:
            self.arrival["t"] += dt
            if self.arrival["t"] > 3.2:
                self.arrival = None
        if self.mode == "transition":
            self.transition["t"] += dt
            if self.transition["t"] >= self.transition["dur"]:
                self.transition = None
                self.mode = "walk"
            return
        if self.mode == "card":
            self.card_t += dt
        if self.mode == "dialogue" and self.dialogue:
            self.dialogue.update(dt)
        if self.mode == "walk":
            self.update_player(dt)
        self.update_npcs(dt)
        self.particles.update(dt, self.t)
        p = self.player
        fx, fy = p.facing
        if fy == 0:
            tx, ty = p.x - fx * 15, p.y + 1
        else:
            tx, ty = p.x + 12, p.y - fy * 3
        k = 1 - math.exp(-12 * dt)
        self.suitcase[0] += (tx - self.suitcase[0]) * k
        self.suitcase[1] += (ty - self.suitcase[1]) * k
        self.target = self.find_target() if self.mode == "walk" else None

    def update_player(self, dt):
        keys = pygame.key.get_pressed()
        dx = (keys[pygame.K_RIGHT] or keys[pygame.K_d]) - (keys[pygame.K_LEFT] or keys[pygame.K_a])
        dy = (keys[pygame.K_DOWN] or keys[pygame.K_s]) - (keys[pygame.K_UP] or keys[pygame.K_w])
        self.move_player(dx, dy, dt)

    def move_player(self, dx, dy, dt):
        p = self.player
        if not (dx or dy):
            p.moving = False
            return
        if dx and not dy:
            p.facing = (dx, 0)
        elif dy and not dx:
            p.facing = (0, dy)
        elif p.facing not in ((dx, 0), (0, dy)):
            p.facing = (dx, 0)
        n = math.hypot(dx, dy)
        vx, vy = dx / n * SPEED * dt, dy / n * SPEED * dt
        if not self.blocked(p.rect_at(p.x + vx, p.y)):
            p.x += vx
        if not self.blocked(p.rect_at(p.x, p.y + vy)):
            p.y += vy
        p.moving = True
        p.walk += dt * 12

    def update_npcs(self, dt):
        plane = self.state.plane
        p = self.player
        for n in self.npcs:
            pace = n.data.get("pace", {}).get(plane)
            busy = self.mode == "dialogue" and self.dialogue and self.dialogue.npc is n
            n.moving = False
            if pace and not busy:
                if n.wait > 0:
                    n.wait -= dt
                else:
                    lo, hi = pace[0] * TILE + 16, pace[1] * TILE + 16
                    step = 36 * dt * n.dir
                    nr = pygame.Rect(int(n.x + step) - 9, int(n.y) - 9, 18, 10)
                    if not nr.colliderect(p.rect_at(p.x, p.y)):
                        n.x += step
                        n.moving = True
                        n.walk += dt * 9
                        n.facing = (n.dir, 0)
                        if (n.dir > 0 and n.x >= hi) or (n.dir < 0 and n.x <= lo):
                            n.x = min(max(n.x, lo), hi)
                            n.dir *= -1
                            n.wait = 1.8
                n.home_x = n.x
            if not n.moving and not n.seated(plane):
                dxp, dyp = p.x - n.x, p.y - n.y
                if math.hypot(dxp, dyp) < 110:
                    if abs(dxp) > abs(dyp):
                        n.facing = (1 if dxp > 0 else -1, 0)
                    else:
                        n.facing = (0, 1 if dyp > 0 else -1)
                elif not pace:
                    n.facing = (0, 1)

    # ---- input ----------------------------------------------------------------
    def handle_event(self, e):
        if e.type == pygame.QUIT:
            self.running = False
            return
        if e.type != pygame.KEYDOWN:
            return
        k = e.key
        if k == pygame.K_F11 or (k == pygame.K_f and self.mode != "dialogue"):
            pygame.display.toggle_fullscreen()
            return
        if k == pygame.K_m:
            self.audio.toggle_mute()
            return
        if self.fx:
            return
        getattr(self, "key_" + self.scene)(k)

    def key_title(self, k):
        if k in (pygame.K_RETURN, pygame.K_SPACE, pygame.K_e):
            self.audio.play("tick", 0.6)
            if self.skip_intro:
                self.fade(self.start_play)
            else:
                self.fade(self.begin_intro)
        elif k == pygame.K_ESCAPE:
            self.running = False

    def begin_intro(self):
        self.scene = "intro"
        self.slides = story.INTRO_SLIDES
        self.slide = 0
        self.scene_t = 0.0
        self.audio.set_plane("home")

    def key_intro(self, k):
        if k == pygame.K_ESCAPE:
            self.fade(self.start_play)
        elif k in (pygame.K_RETURN, pygame.K_SPACE, pygame.K_e):
            if self.scene_t < 0.5:
                self.scene_t = 0.5
            elif self.slide + 1 < len(self.slides):
                self.slide += 1
                self.scene_t = 0.0
            else:
                self.fade(self.start_play)

    def key_ending(self, k):
        if k in (pygame.K_RETURN, pygame.K_SPACE, pygame.K_e, pygame.K_ESCAPE):
            if self.scene_t < 0.6 and k != pygame.K_ESCAPE:
                self.scene_t = 0.6
            elif self.slide + 1 < len(self.slides) and k != pygame.K_ESCAPE:
                self.slide += 1
                self.scene_t = 0.0
            else:
                self.fade(self.back_to_title)

    def back_to_title(self):
        self.scene = "title"
        self.scene_t = 0.0
        self.reset()
        self.audio.set_plane("hesk")

    def key_play(self, k):
        m = self.mode
        confirm = (pygame.K_RETURN, pygame.K_SPACE, pygame.K_e, pygame.K_KP_ENTER)
        if m == "walk":
            if k in confirm:
                self.interact()
            elif k in (pygame.K_LSHIFT, pygame.K_RSHIFT, pygame.K_TAB):
                self.open_dial()
            elif pygame.K_1 <= k <= pygame.K_4:
                if "can_shift" in self.state.flags:
                    self.shift_to(PLANES[k - pygame.K_1])
                else:
                    self.open_dial()
            elif k == pygame.K_j:
                self.mode = "journal"
                self.journal_scroll = 0
                self.audio.play("tick", 0.6)
            elif k == pygame.K_ESCAPE:
                self.mode = "pause"
        elif m == "dialogue":
            d = self.dialogue
            if d.is_choice:
                n = len(d.cur[1])
                if k in (pygame.K_UP, pygame.K_w):
                    d.sel = (d.sel - 1) % n
                    self.audio.play("tick", 0.4)
                elif k in (pygame.K_DOWN, pygame.K_s):
                    d.sel = (d.sel + 1) % n
                    self.audio.play("tick", 0.4)
                elif pygame.K_1 <= k < pygame.K_1 + n:
                    d.choose(k - pygame.K_1)
                elif k in confirm:
                    d.press()
            elif k in confirm or k == pygame.K_ESCAPE:
                d.press()
            if d.done:
                self.close_dialogue()
        elif m == "dial":
            if k in (pygame.K_LEFT, pygame.K_a):
                self.dial_sel = (self.dial_sel - 1) % len(PLANES)
                self.audio.play("tick", 0.4)
            elif k in (pygame.K_RIGHT, pygame.K_d):
                self.dial_sel = (self.dial_sel + 1) % len(PLANES)
                self.audio.play("tick", 0.4)
            elif pygame.K_1 <= k <= pygame.K_4:
                self.shift_to(PLANES[k - pygame.K_1])
            elif k in confirm or k in (pygame.K_LSHIFT, pygame.K_RSHIFT):
                self.shift_to(PLANES[self.dial_sel])
            elif k in (pygame.K_ESCAPE, pygame.K_TAB):
                self.mode = "walk"
        elif m == "journal":
            if k in (pygame.K_j, pygame.K_ESCAPE):
                self.mode = "walk"
            elif k in (pygame.K_LEFT, pygame.K_a):
                self.journal_tab = (self.journal_tab - 1) % 5
                self.journal_scroll = 0
                self.audio.play("tick", 0.4)
            elif k in (pygame.K_RIGHT, pygame.K_d):
                self.journal_tab = (self.journal_tab + 1) % 5
                self.journal_scroll = 0
                self.audio.play("tick", 0.4)
            elif k in (pygame.K_UP, pygame.K_w):
                self.journal_scroll = max(0, self.journal_scroll - 40)
            elif k in (pygame.K_DOWN, pygame.K_s):
                self.journal_scroll += 40
        elif m == "card":
            if k in confirm and self.card_t > 0.6:
                self.dismiss_card()
        elif m == "pause":
            if k == pygame.K_ESCAPE:
                self.mode = "walk"
            elif k == pygame.K_r:
                self.fade(self.start_play)
            elif k == pygame.K_q:
                self.running = False

    # ---- drawing: world -----------------------------------------------------------
    def draw_world(self, surf):
        plane = self.state.plane
        p = self.player
        surf.blit(self.statics[plane], (0, 0))
        self.scenery.draw(surf, plane, self.t, self.state.flags, self.fonts)
        ents = [(n.y, 0, n) for n in self.npcs]
        ents.append((p.y, 1, p))
        ents.append((self.suitcase[1] - 0.5, 2, None))
        for _, kind, obj in sorted(ents, key=lambda e: e[0]):
            if kind == 0:
                art.draw_person(surf, obj.x, obj.y, obj.look(plane), self.t, obj.facing,
                                obj.seated(plane), obj.moving, obj.walk, obj.phase)
            elif kind == 1:
                art.draw_person(surf, p.x, p.y, story.PLAYER_LOOK, self.t, p.facing,
                                False, p.moving, p.walk, 0.0)
            else:
                art.draw_suitcase(surf, *self.suitcase)
        self.particles.draw(surf, self.t)
        if plane == "hesk":
            lights = self.scenery.lights(plane) + self.particles.firefly_lights()
            lights.append((int(p.x), int(p.y) - 16, 150, None))
            for n in self.npcs:
                lights.append((int(n.x), int(n.y) - 20, 64, None))
                if n.look(plane).get("accessory") == "lantern":
                    lights.append((int(n.x) + 14, int(n.y) - 22, 70, (255, 190, 110)))
            self.darkness.draw(surf, lights)
        elif plane == "ambrine":
            surf.fill((14, 8, 0), special_flags=pygame.BLEND_RGB_ADD)
        surf.blit(self.vignette, (0, 0))

    def draw_world_labels(self, surf):
        plane = self.state.plane
        p = self.player
        f = self.fonts["ui_s"]
        tgt = self.target
        for n in self.npcs:
            if tgt and tgt[0] == "npc" and tgt[1] is n:
                continue
            if math.hypot(n.x - p.x, n.y - p.y) < 130:
                text(surf, f, n.name(plane), (240, 236, 226), (n.x, n.y - 50), "midbottom", 200, shadow=True)
        if not tgt:
            return
        if tgt[0] == "npc":
            n = tgt[1]
            label = f"Talk to {n.name(plane)}"
            pos = (n.x, n.y - 52)
        else:
            tx, ty = tgt[2]
            label = story.OBJECTS[plane][tgt[1]][0]
            pos = (tx * TILE + 16, max(28, ty * TILE - 4))
        fb = self.fonts["ui_b"]
        w = fb.size(label)[0] + 46
        r = pygame.Rect(0, 0, w, 28)
        r.midbottom = (int(pos[0]), int(pos[1] + math.sin(self.t * 4) * 2))
        r.clamp_ip(pygame.Rect(4, 4, MAP_W - 8, MAP_H - 8))
        panel(surf, r, (14, 14, 22), 220, INFO[plane]["color"], radius=8)
        kc = pygame.Rect(r.x + 6, r.y + 4, 20, 20)
        pygame.draw.rect(surf, INFO[plane]["color"], kc, border_radius=4)
        text(surf, fb, "E", (20, 20, 28), kc.center, "center")
        text(surf, fb, label, INK, (kc.right + 8, r.centery), "midleft")

    def draw_bar(self, surf):
        s = self.state
        col = INFO[s.plane]["color"]
        bar = pygame.Rect(0, MAP_H, W, H - MAP_H)
        pygame.draw.rect(surf, (12, 12, 18), bar)
        pygame.draw.line(surf, col, (0, MAP_H), (W, MAP_H), 2)
        cx, cy = 30, MAP_H + 32
        pygame.draw.circle(surf, col, (cx, cy), 12)
        pygame.draw.circle(surf, (12, 12, 18), (cx, cy), 6)
        a = self.t * 1.5
        pygame.draw.circle(surf, col, (int(cx + math.cos(a) * 9), int(cy + math.sin(a) * 9)), 3)
        text(surf, self.fonts["h2"], INFO[s.plane]["long"], INK, (52, MAP_H + 9))
        text(surf, self.fonts["ui_s"], INFO[s.plane]["epithet"], DIM, (53, MAP_H + 38))

        f = self.fonts["ui_s"]
        x = 330
        y = MAP_H + 11
        x = keycap(surf, f, "E", (x, y)).right + 6
        x = text(surf, f, "talk / look", DIM, (x, y + 2)).right + 16
        if "can_shift" in s.flags:
            x = keycap(surf, f, "SHIFT", (x, y), (70, 60, 100)).right + 6
            x = text(surf, f, "change plane", DIM, (x, y + 2)).right + 16
        jcol = (60, 60, 72)
        if self.journal_flash > 0 and int(self.journal_flash * 3) % 2 == 0:
            jcol = shade_ui(col)
        x = keycap(surf, f, "J", (x, y), jcol).right + 6
        x = text(surf, f, "journal" + (" (new)" if self.journal_flash > 0 else ""), DIM, (x, y + 2)).right + 16
        x = keycap(surf, f, "ESC", (x, y)).right + 6
        text(surf, f, "menu", DIM, (x, y + 2))
        carrying = ", ".join(s.items) if s.items else "your suitcase"
        text(surf, f, f"Carrying: {carrying}", (120, 120, 132), (330, MAP_H + 40))

        text(surf, self.fonts["tiny"], "UNDERSTANDING", DIM, (W - 92, MAP_H + 12), "midtop")
        for i, plane in enumerate(story.STORY_PLANES):
            done = plane in s.understood
            diamond(surf, (W - 124 + i * 32, MAP_H + 42), 10, INFO[plane]["color"], done)

    def draw_dialogue(self, surf):
        d = self.dialogue
        if not d or not d.cur:
            return
        plane = self.state.plane
        col = INFO[plane]["color"]
        box = pygame.Rect(16, MAP_H - 182, W - 32, 170)
        panel(surf, box, (14, 14, 22), 238, col, radius=14)
        cur = d.cur
        tx = box.x + 28
        tw = box.w - 56
        if cur[0] == "say":
            who = cur[1]
            if who == "you":
                look, name, role = story.PLAYER_LOOK, "You", "a stranded traveler"
            else:
                data = story.NPCS[who]
                look, name, role = data["looks"][plane], data["names"][plane], data["roles"][plane]
            talking = not d.full()
            art.draw_portrait(surf, (box.x + 16, box.y + 18, 120, 120), look, self.t, talking, col)
            tx = box.x + 156
            tw = box.right - tx - 28
            nr = text(surf, self.fonts["h2"], name, col, (tx, box.y + 14))
            text(surf, self.fonts["ui_s"], role, DIM, (nr.right + 10, nr.bottom - 4), "bottomleft")
            font = self.fonts["body"]
            ty = box.y + 50
        elif cur[0] == "nar":
            if d.title:
                text(surf, self.fonts["ui_b"], d.title.upper(), col, (tx, box.y + 16))
                ty = box.y + 44
            else:
                ty = box.y + 26
            font = self.fonts["italic"]
        else:
            if d.npc:
                look = d.npc.look(plane)
                art.draw_portrait(surf, (box.x + 16, box.y + 18, 120, 120), look, self.t, False, col)
                tx = box.x + 156
                tw = box.right - tx - 28
                nr = text(surf, self.fonts["h2"], d.npc.name(plane), col, (tx, box.y + 14))
                text(surf, self.fonts["ui_b"], "WHAT DO YOU DO?", DIM, (nr.right + 14, nr.bottom - 4), "bottomleft")
            else:
                text(surf, self.fonts["ui_b"], "WHAT DO YOU DO?", col, (tx, box.y + 16))
            for i, (label, _) in enumerate(cur[1]):
                y = box.y + 48 + i * 34
                sel = i == d.sel
                r = pygame.Rect(tx - 8, y - 4, tw, 30)
                if sel:
                    panel(surf, r, col, 60, col, radius=8, width=1)
                text(surf, self.fonts["body"], f"{i + 1}.  {label}", INK if sel else DIM, (tx + 6, y))
            return
        lines = wrap(font, d.line(), tw)
        remaining = int(d.shown)
        for i, ln in enumerate(lines):
            if remaining <= 0:
                break
            part = ln[:remaining]
            remaining -= len(ln) + 1
            text(surf, font, part, INK, (tx, ty + i * 27))
        if d.full() and int(self.t * 2.5) % 2 == 0:
            x, y = box.right - 28, box.bottom - 22
            pygame.draw.polygon(surf, col, [(x - 7, y - 4), (x + 7, y - 4), (x, y + 4)])

    def toast_life(self):
        return 3.6 if len(self.toasts) == 1 else 2.2

    def draw_toasts(self, surf):
        if not self.toasts:
            return
        tst = self.toasts[0]
        tt = tst["t"]
        a = max(0.0, min(1.0, tt / 0.25, (self.toast_life() - tt) / 0.4))
        f = self.fonts["ui_b"]
        w = f.size(tst["text"])[0] + 40
        r = pygame.Rect(0, 0, w, 36)
        r.midtop = (W // 2, 14 - int((1 - a) * 10))
        col = INFO[self.state.plane]["color"]
        panel(surf, r, (14, 14, 22), int(225 * a), col, radius=18)
        text(surf, f, tst["text"], INK, r.center, "center", int(255 * a))

    def draw_arrival(self, surf):
        ar = self.arrival
        if not ar or ar["t"] < 0 or self.mode not in ("walk", "transition"):
            return
        t = ar["t"]
        a = max(0.0, min(1.0, t / 0.5, (3.2 - t) / 0.9))
        info = INFO[ar["plane"]]
        text(surf, self.fonts["h1"], info["long"], INK, (W // 2, 120), "center", int(255 * a), shadow=True)
        text(surf, self.fonts["italic"], info["epithet"], info["color"], (W // 2, 162), "center", int(255 * a), shadow=True)

    def draw_transition(self, surf):
        tr = self.transition
        p = min(1.0, tr["t"] / tr["dur"])
        e = p * p * (3 - 2 * p)
        surf.blit(tr["new"], (0, 0))
        self.wave.fill((255, 0, 255))
        band = 6
        for y in range(0, MAP_H, band):
            off = (math.sin(y * 0.045 + p * 14) * 70 + math.sin(y * 0.013 - p * 7) * 40) * e
            self.wave.blit(tr["old"], (int(off), y), pygame.Rect(0, y, MAP_W, band))
        self.wave.set_alpha(int(255 * (1 - e)))
        surf.blit(self.wave, (0, 0))
        col = INFO[self.state.plane]["color"]
        ring = pygame.Surface((MAP_W, MAP_H), pygame.SRCALPHA)
        cx, cy = int(self.player.x), int(self.player.y) - 16
        for i in range(3):
            q = e - i * 0.12
            if q > 0:
                rad = int(q * 1100)
                pygame.draw.circle(ring, (*col, int(200 * (1 - q))), (cx, cy), rad, max(2, int(16 * (1 - q))))
        flash = int(110 * math.sin(math.pi * p) ** 2)
        ring.fill((255, 255, 255, flash), special_flags=pygame.BLEND_RGBA_MAX)
        surf.blit(ring, (0, 0))

    # ---- drawing: overlays -----------------------------------------------------------
    def draw_dial(self, surf):
        dim(surf, 170, (6, 6, 14))
        s = self.state
        text(surf, self.fonts["h1"], "Change planes", INK, (W // 2, 92), "center", shadow=True)
        text(surf, self.fonts["italic"], "Same room. Same people, more or less. Different everything else.",
             DIM, (W // 2, 132), "center")
        cw, ch, gap = 200, 250, 22
        x0 = (W - (4 * cw + 3 * gap)) // 2
        for i, plane in enumerate(PLANES):
            info = INFO[plane]
            sel = i == self.dial_sel
            r = pygame.Rect(x0 + i * (cw + gap), 180 - (12 if sel else 0), cw, ch)
            panel(surf, r, (18, 18, 28), 245, info["color"] if sel else (70, 70, 84), radius=14, width=3 if sel else 1)
            thumb = self.thumbs[plane].copy()
            visited = plane in s.visited
            if not visited:
                thumb.fill((70, 70, 80), special_flags=pygame.BLEND_RGB_MULT)
                thumb.fill((40, 40, 50), special_flags=pygame.BLEND_RGB_ADD)
            surf.blit(thumb, (r.x + 12, r.y + 12))
            pygame.draw.rect(surf, (0, 0, 0), (r.x + 12, r.y + 12, 176, 106), 1)
            if not visited:
                text(surf, self.fonts["h1"], "?", INK, (r.centerx, r.y + 65), "center")
            text(surf, self.fonts["ui_s"], str(i + 1), DIM, (r.x + 14, r.y + 128))
            text(surf, self.fonts["h2"], info["name"], info["color"], (r.centerx, r.y + 140), "midtop")
            ep = info["epithet"] if visited else "Unvisited"
            for j, ln in enumerate(wrap(self.fonts["ui_s"], ep, cw - 24)):
                text(surf, self.fonts["ui_s"], ln, DIM, (r.centerx, r.y + 172 + j * 17), "midtop")
            if plane == s.plane:
                text(surf, self.fonts["tiny"], "YOU ARE HERE", INK, (r.centerx, r.bottom - 18), "center")
            elif plane in s.understood:
                diamond(surf, (r.centerx, r.bottom - 18), 7, info["color"], True)
        text(surf, self.fonts["ui"], "ARROWS  choose      ENTER  shift      1-4  quick shift      ESC  cancel",
             DIM, (W // 2, 470), "center")

    def draw_card(self, surf):
        dim(surf, 180, (4, 4, 10))
        plane = self.pending_cards[0]
        info = INFO[plane]
        a = min(1.0, self.card_t / 0.5)
        r = pygame.Rect(150, 120, 660, 380)
        r.y += int((1 - a) * 20)
        panel(surf, r, (16, 16, 26), 248, info["color"], radius=18, width=3)
        text(surf, self.fonts["ui_b"], "U N D E R S T A N D I N G     G A I N E D", info["color"], (r.centerx, r.y + 30), "center")
        text(surf, self.fonts["h1"], info["name"], INK, (r.centerx, r.y + 78), "center")
        text(surf, self.fonts["italic"], info["epithet"], DIM, (r.centerx, r.y + 116), "center")
        for i, ln in enumerate(wrap(self.fonts["italic"], info["understanding"], r.w - 110)):
            text(surf, self.fonts["italic"], ln, INK, (r.centerx, r.y + 160 + i * 28), "center")
        for i, p in enumerate(story.STORY_PLANES):
            diamond(surf, (r.centerx - 40 + i * 40, r.bottom - 72), 11, INFO[p]["color"], p in self.state.understood)
        if "all_done" in self.state.flags and len(self.pending_cards) == 1:
            msg = "Somewhere, a departures board is flickering."
        else:
            msg = f"{len(self.state.understood)} of 3 planes understood"
        text(surf, self.fonts["ui"], msg, DIM, (r.centerx, r.bottom - 42), "center")
        if self.card_t > 0.6 and int(self.t * 2) % 2 == 0:
            text(surf, self.fonts["ui_s"], "press ENTER", DIM, (r.centerx, r.bottom - 18), "center")

    def draw_pause(self, surf):
        dim(surf, 170, (4, 4, 10))
        r = pygame.Rect(0, 0, 420, 300)
        r.center = (W // 2, H // 2 - 20)
        panel(surf, r, (16, 16, 26), 245, INFO[self.state.plane]["color"], radius=16)
        text(surf, self.fonts["h1"], "Paused", INK, (r.centerx, r.y + 46), "center")
        rows = [("ESC", "resume"), ("J", "journal (from the game)"), ("F", "toggle fullscreen"),
                ("M", "mute / unmute" + (" (muted)" if self.audio.muted else "")),
                ("R", "restart from the beginning"), ("Q", "quit")]
        for i, (k, label) in enumerate(rows):
            y = r.y + 92 + i * 32
            keycap(surf, self.fonts["ui_s"], k, (r.x + 80, y))
            text(surf, self.fonts["ui"], label, INK, (r.x + 140, y + 1))

    def draw_journal(self, surf):
        dim(surf, 160)
        s = self.state
        page = pygame.Rect(36, 24, W - 72, H - 48)
        pygame.draw.rect(surf, (90, 70, 52), page.inflate(8, 8), border_radius=14)
        pygame.draw.rect(surf, PAPER, page, border_radius=12)
        for y in range(page.y + 70, page.bottom - 40, 28):
            pygame.draw.line(surf, (226, 216, 196), (page.x + 20, y), (page.right - 20, y))
        tabs = ["People"] + [INFO[p]["name"] if p in s.visited else "???" for p in PLANES]
        x = page.x + 20
        for i, label in enumerate(tabs):
            col = (110, 96, 84) if i == 0 else INFO[PLANES[i - 1]]["color"]
            w = self.fonts["ui_b"].size(label)[0] + 30
            r = pygame.Rect(x, page.y + 16, w, 30)
            if i == self.journal_tab:
                pygame.draw.rect(surf, col, r, border_radius=8)
                text(surf, self.fonts["ui_b"], label, (24, 20, 18), r.center, "center")
            else:
                pygame.draw.rect(surf, col, r, 2, border_radius=8)
                text(surf, self.fonts["ui_b"], label, (110, 100, 90), r.center, "center")
            x = r.right + 10
        text(surf, self.fonts["ui_s"], "JOURNAL", (150, 136, 120), (page.right - 24, page.y + 24), "topright")
        area = pygame.Rect(page.x + 32, page.y + 62, page.w - 64, page.h - 104)
        if self.journal_tab == 0:
            self.draw_people(surf, area)
        else:
            self.draw_plane_page(surf, area, PLANES[self.journal_tab - 1])
        text(surf, self.fonts["ui_s"], "LEFT / RIGHT  turn page      UP / DOWN  scroll      J  close",
             (130, 118, 104), (page.centerx, page.bottom - 18), "center")

    def draw_people(self, surf, area):
        s = self.state
        text(surf, self.fonts["h2"], "Same faces, different worlds", PAPER_INK, (area.x, area.y + 4))
        text(surf, self.fonts["journal_i"], "Everyone you've met, in every plane you've visited.",
             (110, 98, 88), (area.x, area.y + 34))
        cw = area.w // 4
        top = area.y + 70
        for c, plane in enumerate(PLANES):
            name = INFO[plane]["name"] if plane in s.visited else "???"
            text(surf, self.fonts["ui_b"], name.upper(), shade_ui(INFO[plane]["color"], 0.6), (area.x + c * cw + 4, top))
        rh = 72
        for r_i, nid in enumerate(["marisol", "ruth", "pip", "dev", "hale"]):
            y = top + 24 + r_i * rh
            data = story.NPCS[nid]
            for c, plane in enumerate(PLANES):
                x = area.x + c * cw
                if (plane, nid) in s.met:
                    art.draw_portrait(surf, (x, y, 56, 56), data["looks"][plane], self.t + r_i, False, INFO[plane]["color"])
                    text(surf, self.fonts["ui_b"], data["names"][plane], PAPER_INK, (x + 64, y + 4))
                    for j, ln in enumerate(wrap(self.fonts["ui_s"], data["roles"][plane], cw - 72)[:2]):
                        text(surf, self.fonts["ui_s"], ln, (110, 98, 88), (x + 64, y + 24 + j * 15))
                else:
                    pygame.draw.rect(surf, (222, 212, 192), (x, y, 56, 56), border_radius=8)
                    text(surf, self.fonts["h2"], "?", (180, 168, 150), (x + 28, y + 28), "center")
        y = top + 24 + 5 * rh + 4
        if any(nid == "teodor" for _, nid in s.met):
            text(surf, self.fonts["journal_i"], "Teodor looks exactly the same in every plane. Travelers don't change.",
                 (110, 98, 88), (area.x, y))

    def draw_plane_page(self, surf, area, plane):
        s = self.state
        info = INFO[plane]
        if plane not in s.visited:
            text(surf, self.fonts["h1"], "???", PAPER_INK, (area.x, area.y + 4))
            text(surf, self.fonts["journal_i"], "You haven't been here yet. Learn how to turn, then press SHIFT.",
                 (110, 98, 88), (area.x, area.y + 60))
            return
        prev = surf.get_clip()
        surf.set_clip(area)
        y = area.y + 4 - self.journal_scroll
        text(surf, self.fonts["h1"], info["long"], PAPER_INK, (area.x, y))
        y += 48
        text(surf, self.fonts["journal_i"], info["epithet"], shade_ui(info["color"], 0.55), (area.x, y))
        y += 36
        if plane == "home":
            und = ("Your own plane. Everything here seems normal, which is exactly what "
                   "makes it so hard to see.")
            label = "HOME"
        elif plane in s.understood:
            und = info["understanding"]
            label = "UNDERSTANDING"
        else:
            und = "Not yet. Talk to people here. Switch planes. Look for what connects them."
            label = "UNDERSTANDING"
        lines = wrap(self.fonts["journal_i"], und, area.w - 40)
        box = pygame.Rect(area.x, y, area.w, 34 + len(lines) * 24)
        pygame.draw.rect(surf, mix_ui(PAPER, info["color"], 0.25), box, border_radius=10)
        pygame.draw.rect(surf, shade_ui(info["color"], 0.7), box, 2, border_radius=10)
        text(surf, self.fonts["tiny"], label, shade_ui(info["color"], 0.45), (box.x + 20, box.y + 10))
        for i, ln in enumerate(lines):
            text(surf, self.fonts["journal_i"], ln, PAPER_INK, (box.x + 20, box.y + 26 + i * 24))
        y = box.bottom + 20
        notes = s.notes[plane]
        if not notes:
            text(surf, self.fonts["journal_i"], "No notes yet.", (130, 118, 104), (area.x, y))
        for n in notes:
            lines = wrap(self.fonts["journal"], n, area.w - 30)
            pygame.draw.circle(surf, shade_ui(info["color"], 0.6), (area.x + 6, y + 11), 4)
            for ln in lines:
                text(surf, self.fonts["journal"], ln, PAPER_INK, (area.x + 22, y))
                y += 23
            y += 8
        total = y + self.journal_scroll - area.y
        self.journal_scroll = max(0, min(self.journal_scroll, total - area.h + 10))
        surf.set_clip(prev)

    # ---- drawing: scenes ---------------------------------------------------------
    def draw_plane_cycle(self, surf, t, period=6.0):
        i = int(t / period) % 4
        p = (t % period) / period
        a, b = PLANES[i], PLANES[(i + 1) % 4]
        area = pygame.Surface((MAP_W, MAP_H))
        area.blit(self.statics[a], (0, 0))
        if p > 0.7:
            q = (p - 0.7) / 0.3
            seam = q * (MAP_W + 260) - 130
            for y in range(0, MAP_H, 8):
                sx = int(seam + math.sin(y * 0.03 + t * 3) * 60)
                if sx > 0:
                    area.blit(self.statics[b], (0, y), pygame.Rect(0, y, sx, 8))
        surf.fill((0, 0, 0))
        surf.blit(area, (0, (H - MAP_H) // 2))

    def draw_title(self, surf):
        self.draw_plane_cycle(surf, self.scene_t)
        dim(surf, 172, (6, 6, 16))
        y = 190
        text(surf, self.fonts["title"], "PLANE SHIFTER", INK, (W // 2, y), "center", shadow=True)
        text(surf, self.fonts["italic"], "a short game about other worlds, and the people in them",
             (200, 196, 210), (W // 2, y + 58), "center", shadow=True)
        x = W // 2 - 190
        for plane in PLANES:
            text(surf, self.fonts["ui_b"], INFO[plane]["name"], INFO[plane]["color"], (x, y + 104), "center")
            x += 126
        if int(self.t * 1.6) % 2 == 0:
            text(surf, self.fonts["ui_b"], "Press ENTER to begin", INK, (W // 2, 420), "center", shadow=True)
        text(surf, self.fonts["ui_s"], "Inspired by Ursula K. Le Guin's  Changing Planes  (2003)",
             (180, 176, 190), (W // 2, H - 52), "center")
        text(surf, self.fonts["ui_s"], "F fullscreen   ·   M mute   ·   ESC quit", (130, 128, 140),
             (W // 2, H - 30), "center")

    def draw_slides(self, surf, bg):
        if bg == "home":
            surf.fill((0, 0, 0))
            surf.blit(self.statics["home"], (0, (H - MAP_H) // 2))
            dim(surf, 205, (4, 4, 10))
            for k in range(40):
                x = (k * 97 + self.t * 40) % W
                y = (k * 61 + self.t * 260) % H
                pygame.draw.line(surf, (60, 66, 80), (x, y), (x - 4, y + 12))
        else:
            self.draw_plane_cycle(surf, self.t, 7.0)
            dim(surf, 195, (4, 4, 10))
        a = int(255 * min(1.0, self.scene_t / 0.6))
        msg = self.slides[self.slide]
        if msg == "__credits__":
            for i, ln in enumerate(story.CREDITS):
                f = self.fonts["title"] if i == 0 else self.fonts["italic"] if i == 2 else self.fonts["body"]
                text(surf, f, ln, INK, (W // 2, 170 + i * 44 + (24 if i else 0)), "center", a, shadow=True)
            if self.scene_t > 1.0:
                text(surf, self.fonts["ui_s"], "press ENTER to return to the title", DIM, (W // 2, H - 40), "center")
            return
        lines = wrap(self.fonts["slide"], msg, 700)
        y0 = H // 2 - len(lines) * 20
        for i, ln in enumerate(lines):
            text(surf, self.fonts["slide"], ln, INK, (W // 2, y0 + i * 40), "center", a, shadow=True)
        for i in range(len(self.slides)):
            col = INK if i == self.slide else (80, 80, 92)
            pygame.draw.circle(surf, col, (W // 2 - (len(self.slides) - 1) * 9 + i * 18, H - 64), 4)
        if self.scene_t > 0.8 and int(self.t * 2) % 2 == 0:
            text(surf, self.fonts["ui_s"], "press ENTER", DIM, (W // 2, H - 38), "center")

    def draw(self):
        surf = self.screen
        if self.scene == "title":
            self.draw_title(surf)
        elif self.scene == "intro":
            self.draw_slides(surf, "home")
        elif self.scene == "ending":
            self.draw_slides(surf, "cycle")
        else:
            if self.mode == "transition":
                self.draw_transition(self.world)
            else:
                self.draw_world(self.world)
                if self.mode == "walk":
                    self.draw_world_labels(self.world)
            surf.blit(self.world, (0, 0))
            self.draw_bar(surf)
            self.draw_arrival(surf)
            if self.mode == "dialogue":
                self.draw_dialogue(surf)
            elif self.mode == "dial":
                self.draw_dial(surf)
            elif self.mode == "journal":
                self.draw_journal(surf)
            elif self.mode == "card":
                self.draw_card(surf)
            elif self.mode == "pause":
                self.draw_pause(surf)
            if self.mode not in ("journal", "pause", "card"):
                self.draw_toasts(surf)
        if self.fx:
            t = self.fx["t"] / 0.8
            a = t if self.fx["phase"] == "out" else 1 - t
            dim(surf, int(255 * max(0.0, min(1.0, a))))

    async def run(self):
        while self.running:
            dt = min(self.clock.tick(FPS) / 1000.0, 0.05)
            for e in pygame.event.get():
                self.handle_event(e)
            self.update(dt)
            self.draw()
            pygame.display.flip()
            await asyncio.sleep(0)  # lets the browser build (pygbag) draw each frame
        pygame.quit()


def shade_ui(c, f=0.75):
    return tuple(max(0, min(255, int(v * f))) for v in c)


def mix_ui(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


def main():
    args = set(sys.argv[1:])
    game = Game(skip_intro="--skip-intro" in args, fullscreen="--fullscreen" in args)
    asyncio.run(game.run())


if __name__ == "__main__":
    main()
