"""Procedural art: four versions of one room, plus people and portraits.

Nothing here loads an image file. Every plane is painted from the same
LAYOUT with its own palette and props, so the player can recognise the
same place even when everything about it has changed.
"""

import math
import random

import pygame

TILE = 32
COLS, ROWS = 30, 18
MAP_W, MAP_H = COLS * TILE, ROWS * TILE


# --------------------------------------------------------------------------
# Small helpers
# --------------------------------------------------------------------------

def clamp(v, lo=0, hi=255):
    return max(lo, min(hi, int(v)))


def shade(c, f):
    return tuple(clamp(v * f) for v in c[:3])


def mix(a, b, t):
    return tuple(clamp(a[i] + (b[i] - a[i]) * t) for i in range(3))


def vary(c, rng, amt):
    v = rng.randint(-amt, amt)
    return tuple(clamp(x + v) for x in c[:3])


def tr(tx, ty, tw=1, th=1):
    return pygame.Rect(tx * TILE, ty * TILE, tw * TILE, th * TILE)


def vgrad(surf, rect, top, bottom):
    h = max(1, rect.h - 1)
    for i in range(rect.h):
        pygame.draw.line(surf, mix(top, bottom, i / h), (rect.x, rect.y + i), (rect.right - 1, rect.y + i))


def feature_rects(layout):
    """Group the layout's feature letters into rectangles (in tiles)."""
    rows, cols = len(layout), len(layout[0])
    used = [[False] * cols for _ in range(rows)]
    out = []
    for y in range(rows):
        for x in range(cols):
            c = layout[y][x]
            if c in ".#" or used[y][x]:
                continue
            w = 1
            while x + w < cols and layout[y][x + w] == c and not used[y][x + w]:
                w += 1
            h = 1
            while y + h < rows and all(layout[y + h][x + i] == c and not used[y + h][x + i] for i in range(w)):
                h += 1
            for yy in range(y, y + h):
                for xx in range(x, x + w):
                    used[yy][xx] = True
            out.append((c, pygame.Rect(x, y, w, h)))
    return out


_gradient_cache = {}


def radial(radius, color=(255, 255, 255), alpha=255, power=1.6):
    """A soft radial blob, cached by parameters."""
    key = (radius, color, alpha, power)
    if key in _gradient_cache:
        return _gradient_cache[key]
    s = pygame.Surface((radius * 2, radius * 2), pygame.SRCALPHA)
    for r in range(radius, 0, -2):
        a = alpha * (1 - r / radius) ** power
        pygame.draw.circle(s, (*color, clamp(a)), (radius, radius), r)
    _gradient_cache[key] = s
    return s


def glow(surf, pos, radius, color, strength=1.0):
    """Additive coloured glow."""
    c = tuple(clamp(v * strength) for v in color)
    key = ("glow", radius, c)
    g = _gradient_cache.get(key)
    if g is None:
        g = pygame.Surface((radius * 2, radius * 2))
        g.fill((0, 0, 0))
        for r in range(radius, 0, -2):
            f = (1 - r / radius) ** 1.8
            pygame.draw.circle(g, tuple(clamp(v * f) for v in c), (radius, radius), r)
        _gradient_cache[key] = g
    surf.blit(g, (pos[0] - radius, pos[1] - radius), special_flags=pygame.BLEND_RGB_ADD)


def make_vignette(size, strength=150):
    w, h = size
    small = pygame.Surface((96, 58), pygame.SRCALPHA)
    for y in range(58):
        for x in range(96):
            dx = (x - 47.5) / 48
            dy = (y - 28.5) / 29
            d = min(1.0, math.sqrt(dx * dx + dy * dy))
            a = strength * max(0.0, d - 0.55) / 0.45
            small.set_at((x, y), (0, 0, 0, clamp(a ** 1.0)))
    return pygame.transform.smoothscale(small, (w, h))


# --------------------------------------------------------------------------
# Floors and walls
# --------------------------------------------------------------------------

def _floor_home(s, rng):
    s.fill((56, 74, 96))
    for ty in range(ROWS):
        for tx in range(COLS):
            cx, cy = tx * TILE + 16, ty * TILE + 16
            if (tx + ty) % 2 == 0:
                pygame.draw.polygon(s, (68, 90, 116), [(cx, cy - 6), (cx + 6, cy), (cx, cy + 6), (cx - 6, cy)])
                pygame.draw.circle(s, (88, 110, 70), (cx, cy), 1)
            else:
                pygame.draw.circle(s, (48, 64, 84), (cx, cy), 2)
            pygame.draw.rect(s, (64, 84, 108), (tx * TILE, ty * TILE, 2, 2))
    pools = pygame.Surface((MAP_W, MAP_H), pygame.SRCALPHA)
    for gx in range(160, MAP_W, 320):
        for gy in (190, 420):
            for r in range(130, 0, -10):
                a = 3 + (130 - r) / 130 * 22
                pygame.draw.ellipse(pools, (255, 252, 230, clamp(a)), (gx - r * 1.3, gy - r * 0.6, r * 2.6, r * 1.2))
    s.blit(pools, (0, 0))


def _floor_sollow(s, rng):
    s.fill((174, 184, 198))
    for ty in range(ROWS):
        off = 0 if ty % 2 == 0 else 24
        for x in range(-off, MAP_W, 48):
            c = vary((214, 222, 232), rng, 6)
            pygame.draw.rect(s, c, (x + 1, ty * TILE + 1, 46, 30), border_radius=3)
            if rng.random() < 0.3:
                pygame.draw.line(s, shade(c, 0.93), (x + rng.randint(6, 30), ty * TILE + 6),
                                 (x + rng.randint(10, 40), ty * TILE + rng.randint(12, 26)), 1)
    for _ in range(26):
        x = rng.randint(0, MAP_W)
        y = rng.choice([rng.randint(60, 90), rng.randint(500, 540)])
        pygame.draw.ellipse(s, (244, 247, 251), (x, y, rng.randint(30, 80), rng.randint(8, 16)))
    for _ in range(160):
        s.set_at((rng.randint(0, MAP_W - 1), rng.randint(0, MAP_H - 1)), (255, 255, 255))


def _floor_hesk(s, rng):
    s.fill((26, 24, 56))
    for _ in range(140):
        c = rng.choice([(31, 29, 66), (22, 20, 50), (34, 30, 70)])
        pygame.draw.circle(s, c, (rng.randint(0, MAP_W), rng.randint(0, MAP_H)), rng.randint(8, 28))
    for _ in range(420):
        x, y = rng.randint(0, MAP_W), rng.randint(0, MAP_H)
        h = rng.randint(3, 6)
        pygame.draw.line(s, (44, 46, 94), (x, y), (x + rng.randint(-2, 2), y - h))
    for _ in range(70):
        pygame.draw.circle(s, (140, 120, 222), (rng.randint(0, MAP_W), rng.randint(0, MAP_H)), 1)
    for _ in range(36):
        pygame.draw.circle(s, (90, 192, 204), (rng.randint(0, MAP_W), rng.randint(0, MAP_H)), 1)


def _floor_ambrine(s, rng):
    s.fill((196, 150, 98))
    for ty in range(ROWS):
        for tx in range(COLS):
            x, y = tx * TILE, ty * TILE
            pygame.draw.rect(s, vary((230, 190, 132), rng, 5), (x + 1, y + 1, 30, 30), border_radius=2)
            cx, cy = x + 16, y + 16
            if (tx + ty) % 2 == 0:
                for dx, dy in ((5, 0), (-5, 0), (0, 5), (0, -5)):
                    pygame.draw.circle(s, (204, 108, 76), (cx + dx, cy + dy), 3)
                pygame.draw.circle(s, (60, 132, 142), (cx, cy), 2)
            else:
                for dx, dy in ((2, 2), (29, 2), (2, 29), (29, 29)):
                    pygame.draw.circle(s, (212, 168, 112), (x + dx, y + dy), 1)


def _wall_home(s, tx, ty, rng):
    r = tr(tx, ty)
    if ty <= 1:
        pygame.draw.rect(s, (200, 194, 180), r)
        if ty == 0:
            pygame.draw.line(s, (222, 218, 206), r.topleft, r.topright, 2)
            pygame.draw.line(s, (186, 180, 166), (r.x, r.y + 20), (r.right, r.y + 20), 1)
        else:
            pygame.draw.rect(s, (150, 144, 132), (r.x, r.bottom - 6, TILE, 6))
    elif ty == ROWS - 1:
        pygame.draw.rect(s, (176, 170, 156), r)
        pygame.draw.line(s, (140, 134, 122), r.topleft, r.topright, 3)
    else:
        pygame.draw.rect(s, (186, 180, 166), r)
        edge = r.right - 3 if tx == 0 else r.x
        pygame.draw.rect(s, (148, 142, 130), (edge, r.y, 3, TILE))


def _wall_sollow(s, tx, ty, rng):
    r = tr(tx, ty)
    pygame.draw.rect(s, (146, 156, 172), r)
    for i in range(2):
        y = r.y + i * 16
        pygame.draw.line(s, (126, 136, 152), (r.x, y), (r.right, y))
        jx = r.x + (8 if (ty * 2 + i) % 2 else 24)
        pygame.draw.line(s, (126, 136, 152), (jx, y), (jx, y + 16))
        pygame.draw.rect(s, vary((154, 164, 180), rng, 5), (r.x + 2, y + 2, 4, 3))
    if ty == 0:
        pygame.draw.rect(s, (244, 247, 251), (r.x, r.y, TILE, 7))
        for _ in range(2):
            pygame.draw.circle(s, (244, 247, 251), (r.x + rng.randint(3, 29), r.y + 7), rng.randint(2, 4))
    if ty == ROWS - 1:
        for _ in range(3):
            pygame.draw.circle(s, (244, 247, 251), (r.x + rng.randint(0, 32), r.y + 2), rng.randint(3, 7))
    if 1 < ty < ROWS - 1:
        edge = r.right - 3 if tx == 0 else r.x
        pygame.draw.rect(s, (120, 130, 146), (edge, r.y, 3, TILE))


def _wall_hesk(s, tx, ty, rng):
    r = tr(tx, ty)
    pygame.draw.rect(s, (30, 36, 72), r)
    for _ in range(7):
        c = rng.choice([(38, 48, 90), (26, 32, 64), (44, 54, 100)])
        pygame.draw.circle(s, c, (r.x + rng.randint(2, 30), r.y + rng.randint(2, 30)), rng.randint(5, 9))
    if rng.random() < 0.35:
        pygame.draw.circle(s, (214, 190, 255), (r.x + rng.randint(5, 27), r.y + rng.randint(5, 27)), 2)


def _wall_ambrine(s, tx, ty, rng):
    r = tr(tx, ty)
    pygame.draw.rect(s, vary((184, 98, 66), rng, 4), r)
    if ty == 0:
        pygame.draw.rect(s, (236, 208, 168), (r.x, r.y, TILE, 10))
        pygame.draw.line(s, (206, 170, 128), (r.x, r.y + 10), (r.right, r.y + 10), 2)
    if ty == 1:
        pygame.draw.rect(s, (150, 76, 52), (r.x, r.bottom - 5, TILE, 5))
        sag = 8 * math.sin(math.pi * ((tx * TILE) % 64) / 64)
        for i in range(0, TILE, 6):
            ph = ((tx * TILE + i) % 64) / 64
            y = r.y + 4 + 9 * math.sin(math.pi * ph)
            col = [(240, 90, 90), (250, 200, 60), (90, 170, 120)][(tx * 6 + i // 6) % 3]
            pygame.draw.circle(s, col, (r.x + i + 3, int(y)), 3)
    if ty == ROWS - 1:
        pygame.draw.rect(s, (236, 208, 168), (r.x, r.y, TILE, 4))
    if 1 < ty < ROWS - 1:
        edge = r.right - 4 if tx == 0 else r.x
        pygame.draw.rect(s, (232, 200, 160), (edge, r.y, 4, TILE))


# --------------------------------------------------------------------------
# Features
# --------------------------------------------------------------------------

def _mullions(s, R, color, step=64):
    for x in range(R.x + step, R.right, step):
        pygame.draw.rect(s, color, (x - 2, R.y, 4, R.h))


def glass_rect(R):
    return pygame.Rect(R.x + 4, R.y + 6, R.w - 8, R.h - 14)


# ---- Gate 14 ----

def _home_feature(s, c, R, idx, rng, fonts):
    if c == "W":
        pygame.draw.rect(s, (96, 100, 108), R)
        g = glass_rect(R)
        vgrad(s, g, (158, 172, 188), (118, 132, 148))
        for i in range(7):
            bw = rng.randint(18, 40)
            bx = g.x + rng.randint(0, g.w - bw)
            bh = rng.randint(6, 14)
            pygame.draw.rect(s, (104, 116, 130), (bx, g.bottom - 14 - bh, bw, bh))
        rw = pygame.Rect(g.x, g.bottom - 14, g.w, 14)
        pygame.draw.rect(s, (72, 74, 80), rw)
        for x in range(g.x + 4, g.right, 22):
            pygame.draw.line(s, (220, 220, 210), (x, rw.y + 7), (x + 10, rw.y + 7), 2)
        _mullions(s, R, (96, 100, 108))
        pygame.draw.rect(s, (178, 180, 184), (R.x, R.bottom - 8, R.w, 8))
    elif c == "K":
        pygame.draw.rect(s, (64, 66, 72), R)
        pygame.draw.rect(s, (16, 18, 22), R.inflate(-8, -8))
        pygame.draw.rect(s, (40, 42, 48), (R.x + 20, R.bottom - 4, 6, 4))
        pygame.draw.rect(s, (40, 42, 48), (R.right - 26, R.bottom - 4, 6, 4))
    elif c == "B":
        for i in range(R.w // TILE):
            x = R.x + i * TILE
            pygame.draw.rect(s, (74, 86, 106), (x + 3, R.y + 1, 26, 13), border_radius=4)
            pygame.draw.rect(s, (92, 106, 128), (x + 3, R.y + 12, 26, 13), border_radius=3)
            pygame.draw.line(s, (112, 126, 148), (x + 6, R.y + 14), (x + 26, R.y + 14), 1)
            pygame.draw.rect(s, (150, 154, 162), (x + 6, R.y + 25, 3, 6))
            pygame.draw.rect(s, (150, 154, 162), (x + 23, R.y + 25, 3, 6))
            pygame.draw.rect(s, (172, 176, 184), (x - 1, R.y + 8, 3, 15), border_radius=1)
        pygame.draw.rect(s, (172, 176, 184), (R.right - 2, R.y + 8, 3, 15), border_radius=1)
    elif c == "C":
        if R.w > R.h:
            pygame.draw.rect(s, (112, 80, 60), R)
            pygame.draw.rect(s, (228, 222, 212), (R.x, R.y, R.w, 12))
            for x in range(R.x + 8, R.right, 16):
                pygame.draw.line(s, (96, 68, 50), (x, R.y + 16), (x, R.bottom - 3))
            ex = R.x + 1 * TILE
            pygame.draw.rect(s, (176, 180, 188), (ex + 4, R.y - 12, 26, 20), border_radius=3)
            pygame.draw.rect(s, (120, 124, 132), (ex + 4, R.y - 12, 26, 5), border_radius=2)
            pygame.draw.rect(s, (40, 40, 44), (ex + 10, R.y - 4, 3, 5))
            pygame.draw.rect(s, (40, 40, 44), (ex + 20, R.y - 4, 3, 5))
            for k in range(3):
                pygame.draw.rect(s, (244, 244, 240), (R.x + 3 * TILE + 4 + k * 8, R.y + 2, 6, 7), border_radius=1)
            case = pygame.Rect(R.x + 4 * TILE + 2, R.y - 8, 56, 18)
            pygame.draw.rect(s, (196, 218, 228), case, border_radius=3)
            pygame.draw.rect(s, (150, 170, 182), case, 1, border_radius=3)
            for k in range(2):
                pygame.draw.circle(s, (150, 98, 58), (case.x + 14 + k * 26, case.y + 11), 5)
                pygame.draw.circle(s, (186, 132, 82), (case.x + 14 + k * 26, case.y + 9), 4)
        else:
            pygame.draw.rect(s, (228, 222, 212), R)
            pygame.draw.rect(s, (112, 80, 60), (R.x, R.y, 6, R.h))
    elif c == "D":
        if R.w > R.h:
            pygame.draw.rect(s, (44, 64, 116), R)
            pygame.draw.rect(s, (216, 218, 224), (R.x, R.y, R.w, 12))
            lbl = fonts["tiny"].render("GATE 14", True, (236, 240, 250))
            s.blit(lbl, (R.x + 10, R.y + 15))
            m = pygame.Rect(R.x + 2 * TILE + 4, R.y - 10, 22, 15)
            pygame.draw.rect(s, (34, 34, 40), m, border_radius=2)
            pygame.draw.rect(s, (92, 150, 200), m.inflate(-4, -4))
            pygame.draw.rect(s, (34, 34, 40), (m.centerx - 2, m.bottom, 4, 3))
        else:
            pygame.draw.rect(s, (216, 218, 224), R)
            pygame.draw.rect(s, (44, 64, 116), (R.x, R.y, 6, R.h))
    elif c == "P":
        x, y = R.x, R.y
        pygame.draw.polygon(s, (128, 104, 84), [(x + 8, y + 18), (x + 24, y + 18), (x + 22, y + 31), (x + 10, y + 31)])
        for _ in range(9):
            col = rng.choice([(62, 124, 74), (80, 146, 88), (54, 110, 66)])
            pygame.draw.circle(s, col, (x + 16 + rng.randint(-9, 9), y + 8 + rng.randint(-12, 8)), rng.randint(5, 8))
    elif c == "F":
        rug = R.inflate(16, 8)
        pygame.draw.ellipse(s, (44, 62, 94), rug)
        pygame.draw.ellipse(s, (196, 160, 64), rug, 3)
        pygame.draw.ellipse(s, (60, 82, 118), rug.inflate(-40, -30), 2)
        for px, py in (R.topleft, R.topright, R.bottomleft, R.bottomright):
            pygame.draw.circle(s, (150, 154, 162), (px, py - 4), 4)
            pygame.draw.rect(s, (150, 154, 162), (px - 2, py - 18, 4, 14))
            pygame.draw.circle(s, (196, 200, 208), (px, py - 18), 3)
        for a, b in ((R.topleft, R.topright), (R.bottomleft, R.bottomright),
                     (R.topleft, R.bottomleft), (R.topright, R.bottomright)):
            pygame.draw.line(s, (60, 80, 150), (a[0], a[1] - 15), (b[0], b[1] - 15), 2)
        cx, cy = R.center
        pygame.draw.ellipse(s, (40, 44, 52), (cx - 18, cy + 8, 36, 12))
        pygame.draw.rect(s, (62, 66, 76), (cx - 14, cy - 28, 28, 42), border_radius=4)
        pygame.draw.rect(s, (110, 172, 216), (cx - 11, cy - 24, 22, 16), border_radius=2)
        pygame.draw.circle(s, (60, 120, 200), (cx, cy - 38), 8)
        i = fonts["tiny"].render("i", True, (255, 255, 255))
        s.blit(i, i.get_rect(center=(cx, cy - 38)))
    elif c == "G":
        pygame.draw.rect(s, (110, 114, 122), R)
        door = R.inflate(-6, -8)
        pygame.draw.rect(s, (150, 154, 162), door, border_radius=2)
        pygame.draw.rect(s, (120, 140, 162), (door.x + 6, door.y + 22, door.w - 12, 22), border_radius=2)
        pygame.draw.line(s, (120, 124, 132), (door.centerx, door.y + 50), (door.centerx, door.bottom - 4), 1)
        lbl = fonts["tiny"].render("14", True, (40, 44, 52))
        s.blit(lbl, lbl.get_rect(center=(door.centerx, door.y + 14)))


# ---- Sollow ----

def _sollow_feature(s, c, R, idx, rng, fonts):
    if c == "W":
        pygame.draw.rect(s, (186, 174, 148), R)
        g = glass_rect(R)
        vgrad(s, g, (238, 242, 248), (220, 228, 238))
        pts = [(g.x, g.bottom - 16)]
        for x in range(g.x, g.right + 20, 20):
            pts.append((min(x, g.right), g.bottom - 18 - rng.randint(0, 12)))
        pts += [(g.right, g.bottom - 16)]
        pygame.draw.polygon(s, (206, 216, 228), pts)
        lake = pygame.Rect(g.x, g.bottom - 16, g.w, 16)
        pygame.draw.rect(s, (184, 206, 224), lake)
        for _ in range(8):
            x = rng.randint(g.x, g.right - 20)
            pygame.draw.line(s, (222, 234, 244), (x, lake.y + rng.randint(3, 13)), (x + rng.randint(8, 20), lake.y + rng.randint(3, 13)))
        for corner in (g.topleft, (g.right - 1, g.y)):
            pygame.draw.circle(s, (250, 252, 255), corner, 7)
        _mullions(s, R, (186, 174, 148))
        pygame.draw.rect(s, (244, 247, 251), (R.x, R.bottom - 8, R.w, 8))
    elif c == "K":
        pygame.draw.rect(s, (126, 134, 148), R)
        tab = R.inflate(-8, -6)
        pygame.draw.rect(s, (186, 192, 202), tab, border_radius=3)
        pygame.draw.rect(s, (160, 166, 178), tab.inflate(-6, -6), 1, border_radius=2)
        names = ["RUE      0", "HOLLIS  11", "MARO 40212", "DEVO 18090", "OSRIC    3", "PELL"]
        for i, n in enumerate(names):
            img = fonts["tiny"].render(n, True, (104, 112, 128))
            s.blit(img, (tab.x + 8 + (i % 2) * 92, tab.y + 6 + (i // 2) * 15))
    elif c == "B":
        pygame.draw.rect(s, (150, 156, 168), (R.x + 6, R.y + 20, 10, 10))
        pygame.draw.rect(s, (150, 156, 168), (R.right - 16, R.y + 20, 10, 10))
        pygame.draw.rect(s, (168, 174, 186), (R.x + 2, R.y + 8, R.w - 4, 16), border_radius=3)
        pygame.draw.rect(s, (198, 204, 214), (R.x + 2, R.y + 8, R.w - 4, 4), border_radius=2)
        for sx in (R.x + 18, R.x + 86, R.x + 150):
            pygame.draw.ellipse(s, (242, 238, 228), (sx, R.y + 4, 30, 13))
            for k in range(5):
                pygame.draw.circle(s, (246, 242, 232), (sx + 3 + k * 6, R.y + 15), 3)
    elif c == "C":
        if R.w > R.h:
            pygame.draw.rect(s, (156, 162, 176), R)
            pygame.draw.rect(s, (198, 204, 214), (R.x, R.y, R.w, 12))
            for x in range(R.x, R.right, 24):
                pygame.draw.line(s, (138, 144, 158), (x, R.y + 12), (x, R.bottom))
            kx, ky = R.x + 2 * TILE + 16, R.y - 2
            pygame.draw.circle(s, (36, 36, 42), (kx, ky), 9)
            pygame.draw.line(s, (36, 36, 42), (kx + 7, ky - 2), (kx + 15, ky - 8), 3)
            pygame.draw.arc(s, (36, 36, 42), (kx - 8, ky - 16, 16, 14), 0, math.pi, 2)
            for k in (0, 1, 4):
                pygame.draw.rect(s, (232, 228, 218), (R.x + k * TILE + 12, R.y + 2, 7, 6), border_radius=2)
        else:
            pygame.draw.rect(s, (198, 204, 214), R)
            pygame.draw.rect(s, (156, 162, 176), (R.x, R.y, 6, R.h))
    elif c == "D":
        if R.w > R.h:
            pygame.draw.rect(s, (146, 152, 166), R)
            pygame.draw.rect(s, (186, 192, 204), (R.x, R.y, R.w, 12))
            bk = pygame.Rect(R.x + TILE + 4, R.y - 12, 56, 22)
            pygame.draw.rect(s, (110, 70, 52), bk.inflate(4, 4), border_radius=3)
            pygame.draw.rect(s, (246, 240, 226), bk, border_radius=2)
            pygame.draw.line(s, (180, 170, 150), (bk.centerx, bk.y), (bk.centerx, bk.bottom), 1)
            for k in range(4):
                y = bk.y + 4 + k * 4
                pygame.draw.line(s, (180, 172, 156), (bk.x + 4, y), (bk.centerx - 4, y))
                pygame.draw.line(s, (180, 172, 156), (bk.centerx + 4, y), (bk.right - 4, y))
        else:
            pygame.draw.rect(s, (186, 192, 204), R)
            pygame.draw.rect(s, (146, 152, 166), (R.x, R.y, 6, R.h))
    elif c == "P":
        x, y = R.x, R.y
        pygame.draw.ellipse(s, (246, 248, 252), (x + 2, y + 22, 28, 10))
        pygame.draw.rect(s, (236, 236, 230), (x + 13, y - 20, 6, 46))
        for k in range(6):
            pygame.draw.rect(s, (60, 60, 64), (x + 13 + rng.randint(0, 3), y - 16 + k * 7, 3, 2))
        for k in range(7):
            sx, sy = x + 16, y - 16 + k * 5
            ex = sx + rng.choice([-1, 1]) * rng.randint(8, 16)
            ey = sy - rng.randint(6, 12)
            pygame.draw.line(s, (206, 206, 200), (sx, sy), (ex, ey), 1)
            pygame.draw.rect(s, (196, 164, 120), (ex - 2, ey + 2, 4, 5))
    elif c == "F":
        cx, cy = R.center
        outer = pygame.Rect(0, 0, 92, 64)
        outer.center = (cx, cy + 6)
        pygame.draw.ellipse(s, (120, 128, 142), outer.move(0, 6))
        pygame.draw.ellipse(s, (152, 158, 172), outer)
        for a in range(0, 360, 30):
            px = cx + math.cos(math.radians(a)) * 40
            py = cy + 6 + math.sin(math.radians(a)) * 27
            pygame.draw.line(s, (128, 136, 150), (cx + math.cos(math.radians(a)) * 30, cy + 6 + math.sin(math.radians(a)) * 19), (px, py))
        inner = outer.inflate(-22, -18)
        pygame.draw.ellipse(s, (28, 38, 58), inner)
        pygame.draw.arc(s, (210, 216, 226), outer, 0.2, 2.9, 2)
        for px in (outer.x + 4, outer.right - 10):
            pygame.draw.rect(s, (110, 84, 60), (px, R.y - 10, 6, 46))
        pygame.draw.rect(s, (110, 84, 60), (outer.x + 2, R.y - 12, outer.w - 4, 6))
        pygame.draw.line(s, (160, 140, 110), (cx, R.y - 6), (cx, cy - 4), 1)
        pygame.draw.rect(s, (130, 96, 64), (cx - 5, cy - 6, 10, 8), border_radius=2)
    elif c == "G":
        pygame.draw.rect(s, (146, 156, 172), R)
        op = R.inflate(-8, -10)
        pygame.draw.rect(s, (244, 247, 252), op, border_radius=10)
        for k in range(5):
            pygame.draw.ellipse(s, (210, 220, 232), (op.x + 4 + (k % 2) * 8, op.y + 14 + k * 14, 6, 4))


# ---- Hesk ----

def _hesk_feature(s, c, R, idx, rng, fonts):
    if c == "W":
        pygame.draw.rect(s, (44, 34, 74), R)
        g = glass_rect(R)
        vgrad(s, g, (30, 22, 78), (92, 58, 144))
        for _ in range(30):
            s.set_at((rng.randint(g.x, g.right - 1), rng.randint(g.y, g.bottom - 1)), (200, 200, 240))
        if idx == 0:
            pygame.draw.circle(s, (234, 232, 250), (g.x + 64, g.y + 18), 13)
            pygame.draw.circle(s, (210, 208, 232), (g.x + 60, g.y + 15), 3)
            pygame.draw.circle(s, (214, 212, 236), (g.x + 69, g.y + 22), 2)
        else:
            pygame.draw.circle(s, (244, 196, 214), (g.x + 180, g.y + 14), 8)
        pts = [(g.x, g.bottom)]
        for x in range(g.x, g.right + 16, 16):
            pts.append((min(x, g.right), g.bottom - 6 - rng.randint(0, 8)))
        pts.append((g.right, g.bottom))
        pygame.draw.polygon(s, (36, 26, 70), pts)
        _mullions(s, R, (44, 34, 74))
        pygame.draw.rect(s, (54, 44, 92), (R.x, R.bottom - 8, R.w, 8))
    elif c == "K":
        pygame.draw.rect(s, (66, 52, 106), R)
        p = R.inflate(-8, -8)
        pygame.draw.rect(s, (34, 44, 96), p)
        for _ in range(60):
            x, y = rng.randint(p.x, p.right - 8), rng.randint(p.y, p.bottom - 3)
            pygame.draw.line(s, rng.choice([(44, 60, 120), (58, 48, 110), (40, 70, 120)]), (x, y), (x + rng.randint(4, 10), y + rng.randint(-2, 2)), 2)
    elif c == "B":
        segs = R.w // TILE // 3
        for k in range(segs):
            x0 = R.x + k * 3 * TILE
            x1 = x0 + 3 * TILE
            for px in (x0 + 4, x1 - 8):
                pygame.draw.rect(s, (74, 58, 112), (px, R.y - 6, 4, 34))
            w = x1 - x0 - 16
            for i in range(w):
                u = i / w
                sag = 4 * u * (1 - u) * 12
                col = (126, 104, 178) if (i // 5) % 2 else (156, 134, 206)
                pygame.draw.line(s, col, (x0 + 8 + i, R.y + 4 + sag * 0.4), (x0 + 8 + i, R.y + 12 + sag))
            pygame.draw.ellipse(s, (204, 194, 232), (x0 + 10, R.y + 4, 16, 9))
    elif c == "C":
        if R.w > R.h:
            pygame.draw.rect(s, (82, 58, 54), R)
            pygame.draw.rect(s, (116, 88, 78), (R.x, R.y, R.w, 12))
            ox = R.x
            pygame.draw.ellipse(s, (112, 72, 62), (ox + 1, R.y - 18, 32, 34))
            for k in range(4):
                pygame.draw.line(s, (92, 58, 50), (ox + 4, R.y - 10 + k * 7), (ox + 30, R.y - 10 + k * 7))
            pygame.draw.ellipse(s, (40, 20, 20), (ox + 9, R.y - 2, 16, 12))
        else:
            pygame.draw.rect(s, (116, 88, 78), R)
            pygame.draw.rect(s, (82, 58, 54), (R.x, R.y, 6, R.h))
    elif c == "D":
        if R.w > R.h:
            pygame.draw.rect(s, (62, 52, 98), R)
            pygame.draw.rect(s, (84, 72, 128), (R.x, R.y, R.w, 12))
            for k in range(4):
                pr = pygame.Rect(R.x + 8 + k * 26, R.y + 1, 14, 9)
                pygame.draw.rect(s, (222, 214, 240), pr)
                pygame.draw.line(s, (150, 140, 190), (pr.x + 2, pr.y + 3), (pr.right - 3, pr.y + 3))
        else:
            pygame.draw.rect(s, (84, 72, 128), R)
            pygame.draw.rect(s, (62, 52, 98), (R.x, R.y, 6, R.h))
    elif c == "P":
        x, y = R.x, R.y
        for dx, h, col in ((8, 18, (70, 190, 196)), (20, 26, (160, 120, 232)), (14, 10, (90, 210, 210))):
            pygame.draw.rect(s, (200, 200, 222), (x + dx - 2, y + 30 - h, 4, h))
            pygame.draw.ellipse(s, col, (x + dx - 9, y + 26 - h, 18, 10))
            pygame.draw.circle(s, (230, 240, 255), (x + dx - 3, y + 29 - h), 1)
    elif c == "F":
        cx, cy = R.center
        rim = pygame.Rect(0, 0, 112, 72)
        rim.center = (cx, cy + 4)
        pygame.draw.ellipse(s, (64, 58, 104), rim)
        pygame.draw.ellipse(s, (12, 16, 44), rim.inflate(-14, -12))
        pygame.draw.ellipse(s, (170, 170, 214), (cx + 10, cy - 6, 16, 8))
    elif c == "G":
        pygame.draw.rect(s, (30, 36, 72), R)
        op = pygame.Rect(R.x + 3, R.y + 6, 26, R.h - 12)
        pygame.draw.ellipse(s, (18, 20, 52), op)
        for k in range(3):
            pygame.draw.polygon(s, (10, 10, 30), [(op.x + 2, op.bottom - 16 - k * 18), (op.centerx, op.bottom - 28 - k * 18), (op.right - 2, op.bottom - 16 - k * 18), (op.right - 2, op.bottom - 6 - k * 18), (op.x + 2, op.bottom - 6 - k * 18)])
        pygame.draw.ellipse(s, (88, 74, 140), op, 2)


# ---- Ambrine ----

def _ambrine_feature(s, c, R, idx, rng, fonts):
    if c == "W":
        g = R.copy()
        vgrad(s, g, (252, 218, 154), (252, 238, 206))
        for _ in range(5):
            dx = rng.randint(g.x, g.right - 40)
            pygame.draw.ellipse(s, (232, 182, 130), (dx, g.y + 26, 36, 24))
            pygame.draw.rect(s, (226, 172, 120), (dx + 4, g.y + 38, 28, 16))
        for k in range(6):
            sx = g.x + 8 + k * 42
            pygame.draw.rect(s, (160, 100, 64), (sx, g.bottom - 14, 30, 10))
            for j in range(3):
                pygame.draw.circle(s, rng.choice([(240, 90, 80), (250, 200, 60), (120, 180, 90), (240, 240, 230)]), (sx + 6 + j * 9, g.bottom - 16), 4)
            pygame.draw.ellipse(s, (170, 104, 72), (sx + rng.randint(0, 20), g.bottom - 30, 7, 14))
        for x in range(R.x, R.right, 16):
            col = (206, 66, 54) if (x // 16) % 2 else (246, 232, 204)
            pygame.draw.rect(s, col, (x, R.y, 16, 20))
            pygame.draw.circle(s, col, (x + 8, R.y + 20), 8, draw_top_left=False, draw_top_right=False,
                               draw_bottom_left=True, draw_bottom_right=True)
        for px in (R.x + 2, R.right - 6):
            pygame.draw.rect(s, (150, 94, 62), (px, R.y, 4, R.h))
    elif c == "K":
        pygame.draw.rect(s, (170, 110, 70), R)
        p = R.inflate(-8, -6)
        pygame.draw.rect(s, (238, 216, 180), p)
        palette = [(220, 60, 70), (250, 190, 50), (60, 140, 160), (130, 80, 170), (90, 170, 100), (240, 120, 40)]
        for _ in range(150):
            x, y = rng.randint(p.x + 2, p.right - 4), rng.randint(p.y + 2, p.bottom - 12)
            col = rng.choice(palette)
            pygame.draw.line(s, col, (x, y), (x + rng.randint(-2, 2), y + rng.randint(6, 11)), 2)
            pygame.draw.circle(s, shade(col, 0.8), (x, y), 2)
    elif c == "B":
        mat = pygame.Rect(R.x + 2, R.y + 6, R.w - 4, 22)
        pygame.draw.rect(s, (208, 160, 90), mat, border_radius=3)
        for x in range(mat.x, mat.right, 6):
            pygame.draw.line(s, (186, 138, 74), (x, mat.y), (x + 6, mat.bottom))
        for k, bx in enumerate((R.x + 30, R.x + 96, R.x + 160)):
            pygame.draw.ellipse(s, (166, 106, 56), (bx - 12, R.y + 6, 24, 18))
            pygame.draw.ellipse(s, (192, 130, 72), (bx - 12, R.y + 4, 24, 9))
            if k == 0:
                pygame.draw.polygon(s, (220, 60, 80), [(bx, R.y - 8), (bx + 7, R.y), (bx, R.y + 7), (bx - 7, R.y)])
            elif k == 1:
                pygame.draw.rect(s, (240, 240, 230), (bx - 6, R.y - 2, 8, 8), border_radius=2)
                pygame.draw.rect(s, (90, 60, 40), (bx + 2, R.y, 8, 5), border_radius=2)
            else:
                pygame.draw.line(s, (210, 214, 220), (bx - 6, R.y + 4), (bx + 6, R.y - 2), 2)
                pygame.draw.circle(s, (210, 214, 220), (bx - 6, R.y + 4), 3)
    elif c == "C":
        if R.w > R.h:
            pygame.draw.rect(s, (170, 112, 64), R)
            pygame.draw.rect(s, (198, 140, 82), (R.x, R.y, R.w, 12))
            for k in range(9):
                lx = R.x + 6 + k * 20
                pygame.draw.ellipse(s, (216, 166, 98), (lx, R.y - 6, 18, 12))
                pygame.draw.line(s, (180, 120, 60), (lx + 5, R.y - 3), (lx + 9, R.y + 3))
                pygame.draw.line(s, (180, 120, 60), (lx + 10, R.y - 3), (lx + 14, R.y + 3))
        else:
            pygame.draw.rect(s, (198, 140, 82), R)
            pygame.draw.rect(s, (170, 112, 64), (R.x, R.y, 6, R.h))
    elif c == "D":
        if R.w > R.h:
            pygame.draw.rect(s, (152, 98, 58), R)
            pygame.draw.rect(s, (188, 130, 76), (R.x, R.y, R.w, 12))
            for k, col in enumerate([(120, 40, 40), (40, 80, 120), (160, 120, 40), (60, 110, 70)]):
                pygame.draw.rect(s, col, (R.x + 4, R.y - 14 + k * 4, 22, 5))
            bk = pygame.Rect(R.x + TILE + 8, R.y - 8, 50, 16)
            pygame.draw.rect(s, (244, 236, 214), bk, border_radius=2)
            pygame.draw.line(s, (200, 186, 160), (bk.centerx, bk.y), (bk.centerx, bk.bottom))
            for k in range(3):
                pygame.draw.line(s, (170, 150, 120), (bk.x + 4, bk.y + 4 + k * 4), (bk.right - 4, bk.y + 4 + k * 4))
            pygame.draw.circle(s, (30, 30, 40), (R.right - 18, R.y + 2), 5)
            pygame.draw.line(s, (250, 250, 250), (R.right - 18, R.y), (R.right - 6, R.y - 16), 2)
        else:
            pygame.draw.rect(s, (188, 130, 76), R)
            pygame.draw.rect(s, (152, 98, 58), (R.x, R.y, 6, R.h))
    elif c == "P":
        x, y = R.x, R.y
        pygame.draw.polygon(s, (192, 98, 62), [(x + 7, y + 16), (x + 25, y + 16), (x + 22, y + 31), (x + 10, y + 31)])
        pygame.draw.rect(s, (230, 180, 120), (x + 8, y + 19, 16, 3))
        for _ in range(10):
            pygame.draw.circle(s, rng.choice([(92, 142, 72), (110, 160, 84), (78, 128, 62)]), (x + 16 + rng.randint(-11, 11), y + 4 + rng.randint(-12, 10)), rng.randint(5, 8))
        for _ in range(5):
            pygame.draw.circle(s, (150, 76, 120), (x + 16 + rng.randint(-10, 10), y + 4 + rng.randint(-10, 8)), 3)
    elif c == "F":
        cx, cy = R.center
        basin = pygame.Rect(0, 0, 116, 66)
        basin.center = (cx, cy + 10)
        pygame.draw.ellipse(s, (184, 164, 134), basin.move(0, 6))
        pygame.draw.ellipse(s, (214, 194, 164), basin)
        water = basin.inflate(-14, -12)
        pygame.draw.ellipse(s, (96, 172, 204), water)
        for _ in range(30):
            a = rng.random() * math.tau
            d = rng.random() ** 0.5
            pygame.draw.circle(s, (236, 196, 80), (int(cx + math.cos(a) * d * 46), int(cy + 10 + math.sin(a) * d * 22)), 2)
        pygame.draw.rect(s, (210, 190, 160), (cx - 6, cy - 26, 12, 36))
        pygame.draw.ellipse(s, (214, 194, 164), (cx - 22, cy - 32, 44, 14))
        pygame.draw.ellipse(s, (120, 190, 220), (cx - 17, cy - 30, 34, 8))
    elif c == "G":
        pygame.draw.rect(s, (184, 98, 66), R)
        op = R.inflate(-8, -8)
        vgrad(s, op, (255, 246, 214), (255, 226, 170))
        pygame.draw.rect(s, (236, 208, 168), op, 2, border_radius=10)


FLOORS = {"home": _floor_home, "sollow": _floor_sollow, "hesk": _floor_hesk, "ambrine": _floor_ambrine}
WALLS = {"home": _wall_home, "sollow": _wall_sollow, "hesk": _wall_hesk, "ambrine": _wall_ambrine}
FEATURES = {"home": _home_feature, "sollow": _sollow_feature, "hesk": _hesk_feature, "ambrine": _ambrine_feature}


def build_static(plane, layout, features, fonts):
    """Paint everything that never moves for one plane."""
    rng = random.Random(hash(plane) & 0xFFFF)
    rng.seed(sum(map(ord, plane)) * 7919)
    s = pygame.Surface((MAP_W, MAP_H))
    FLOORS[plane](s, rng)
    for ty, row in enumerate(layout):
        for tx, ch in enumerate(row):
            if ch == "#":
                WALLS[plane](s, tx, ty, rng)
    order = sorted(features, key=lambda f: (f[0] not in "WKG", f[1].y))
    counts = {}
    for ch, rect in order:
        idx = counts.get(ch, 0)
        counts[ch] = idx + 1
        FEATURES[plane](s, ch, tr(rect.x, rect.y, rect.w, rect.h), idx, rng, fonts)
    return s


# --------------------------------------------------------------------------
# Animated details
# --------------------------------------------------------------------------

class Scenery:
    """Per-plane animated details that sit on top of the static layer."""

    def __init__(self, features):
        self.rects = {}
        for ch, r in features:
            self.rects.setdefault(ch, []).append(tr(r.x, r.y, r.w, r.h))
        rng = random.Random(42)
        self.stars = [[(rng.randint(0, 247), rng.randint(0, 49), rng.random() * 6) for _ in range(18)]
                      for _ in self.rects.get("W", [])]
        self.pool_stars = [(rng.uniform(-40, 40), rng.uniform(-18, 18), rng.random() * 6) for _ in range(14)]
        self.coin_glints = [(rng.uniform(-46, 46), rng.uniform(-18, 18), rng.random() * 6) for _ in range(10)]

    def counter_main(self):
        return max(self.rects["C"], key=lambda r: r.w)

    def desk_main(self):
        return max(self.rects["D"], key=lambda r: r.w)

    def lights(self, plane):
        """Light sources (x, y, radius, colour) for planes that use darkness."""
        out = []
        if plane != "hesk":
            return out
        for r in self.rects.get("W", []):
            out.append((r.centerx, r.bottom + 10, 120, (90, 70, 190)))
        for r in self.rects.get("F", []):
            out.append((r.centerx, r.centery + 4, 120, (60, 70, 200)))
        for r in self.rects.get("P", []):
            out.append((r.centerx, r.centery + 6, 80, (40, 190, 190)))
        c = self.counter_main()
        out.append((c.x + 17, c.y + 2, 120, (255, 130, 40)))
        d = self.desk_main()
        out.append((d.x + 40, d.y, 100, (255, 180, 80)))
        for r in self.rects.get("K", []):
            out.append((r.centerx, r.bottom + 4, 90, (80, 80, 180)))
        for r in self.rects.get("G", []):
            out.append((r.centerx, r.centery, 60, (80, 80, 160)))
        return out

    def draw(self, s, plane, t, flags, fonts):
        getattr(self, "_draw_" + plane)(s, t, flags, fonts)

    # ---- Gate 14 ----
    def _draw_home(self, s, t, flags, fonts):
        for i, R in enumerate(self.rects.get("W", [])):
            g = glass_rect(R)
            s.set_clip(g)
            if i == 0:
                px = g.x + ((t * 14) % (g.w + 90)) - 45
                py = g.bottom - 22
                pygame.draw.ellipse(s, (236, 238, 242), (px - 22, py - 4, 46, 9))
                pygame.draw.polygon(s, (236, 238, 242), [(px - 20, py), (px - 26, py - 12), (px - 16, py - 2)])
                pygame.draw.line(s, (196, 200, 210), (px - 6, py + 2), (px + 4, py + 8), 3)
                for k in range(4):
                    pygame.draw.rect(s, (90, 110, 140), (px - 6 + k * 6, py - 2, 3, 2))
            for k in range(16):
                x = g.x + ((k * 37 + t * 70) % (g.w + 20)) - 10
                y = g.y + ((k * 53 + t * 150) % g.h)
                pygame.draw.line(s, (206, 216, 230), (x, y), (x - 3, y + 7), 1)
            s.set_clip(None)
        for R in self.rects.get("K", []):
            p = R.inflate(-8, -8)
            f = fonts["mono"]
            s.blit(f.render("DEPARTURES", True, (240, 180, 60)), (p.x + 6, p.y + 2))
            status = "BOARDING" if "all_done" in flags else "DELAYED"
            scol = (90, 230, 120) if status == "BOARDING" else (240, 180, 60)
            if status == "DELAYED" and int(t * 1.5) % 2:
                scol = (150, 110, 40)
            rows = [("1407", "PORTLAND", status, scol), ("212", "DENVER", "CANCELLED", (230, 80, 70)),
                    ("88", "SEATTLE", "DELAYED", (240, 180, 60))]
            for k, (num, city, st, col) in enumerate(rows):
                y = p.y + 15 + k * 12
                s.blit(f.render(num, True, (230, 230, 220)), (p.x + 6, y))
                s.blit(f.render(city, True, (230, 230, 220)), (p.x + 38, y))
                s.blit(f.render(st, True, col), (p.right - 6 - f.size(st)[0], y))
        for R in self.rects.get("G", []):
            col = (80, 230, 120) if "all_done" in flags else (230, 60, 50)
            pygame.draw.circle(s, col, (R.centerx, R.y + 4), 3)

    # ---- Sollow ----
    def _draw_sollow(self, s, t, flags, fonts):
        c = self.counter_main()
        kx, ky = c.x + 2 * TILE + 24, c.y - 12
        puff = pygame.Surface((40, 60), pygame.SRCALPHA)
        for i in range(6):
            ph = (t * 0.5 + i / 6) % 1
            x = 20 + math.sin(ph * 6 + i) * 5
            y = 54 - ph * 48
            pygame.draw.circle(puff, (255, 255, 255, clamp((1 - ph) * 110)), (int(x), int(y)), int(3 + ph * 6))
        s.blit(puff, (kx - 20, ky - 54))
        for R in self.rects.get("W", []):
            g = glass_rect(R)
            s.set_clip(g)
            for k in range(14):
                x = g.x + (k * 41 + math.sin(t + k) * 6) % g.w
                y = g.y + ((k * 29 + t * 18) % g.h)
                pygame.draw.circle(s, (255, 255, 255), (int(x), int(y)), 1)
            s.set_clip(None)
        for R in self.rects.get("F", []):
            a = 0.5 + 0.5 * math.sin(t * 1.3)
            pygame.draw.ellipse(s, mix((28, 38, 58), (120, 140, 170), a * 0.6), (R.centerx - 12, R.centery + 2, 18, 4))

    # ---- Hesk ----
    def _draw_hesk(self, s, t, flags, fonts):
        for i, R in enumerate(self.rects.get("W", [])):
            g = glass_rect(R)
            for x, y, ph in self.stars[i]:
                b = 0.5 + 0.5 * math.sin(t * 2.5 + ph)
                if g.x + x < g.right and g.y + y < g.bottom - 8:
                    col = mix((80, 70, 140), (255, 255, 255), b)
                    s.set_at((g.x + x, g.y + y), col)
                    if b > 0.85:
                        s.set_at((g.x + x + 1, g.y + y), col)
                        s.set_at((g.x + x, g.y + y + 1), col)
        done = "hesk_done" in flags
        for R in self.rects.get("K", []):
            p = R.inflate(-8, -8)
            s.set_clip(p)
            for k in range(6):
                pygame.draw.line(s, (90, 96, 160), (p.x + 20 + k * 22, p.y + 8 + k * 7), (p.x + 42 + k * 22, p.y + 8 + k * 7), 2)
                pygame.draw.line(s, (90, 96, 160), (p.x + 42 + k * 22, p.y + 8 + k * 7), (p.x + 42 + k * 22, p.y + 15 + k * 7), 2)
            if not done:
                ph = (t * 0.35) % 1
                bx = p.x + 24 + ph * 120
                by = p.y + 2 + ph * 40
                box = pygame.Surface((18, 16), pygame.SRCALPHA)
                pygame.draw.rect(box, (176, 112, 70), (0, 0, 18, 16), border_radius=2)
                pygame.draw.rect(box, (120, 72, 40), (0, 0, 18, 16), 2, border_radius=2)
                pygame.draw.circle(box, (230, 200, 80), (9, 8), 2)
                rb = pygame.transform.rotate(box, -ph * 540)
                s.blit(rb, rb.get_rect(center=(int(bx), int(by))))
            else:
                bx, by = p.x + 30, p.y + 22
                pygame.draw.rect(s, (176, 112, 70), (bx, by, 22, 16))
                pygame.draw.polygon(s, (150, 92, 56), [(bx, by), (bx + 22, by), (bx + 28, by - 10), (bx + 6, by - 10)])
                pygame.draw.ellipse(s, (230, 180, 110), (bx + 3, by - 6, 16, 9))
                pygame.draw.lines(s, (232, 214, 150), False, [(bx + 22, by + 12), (bx + 60, by + 16), (bx + 100, by + 6), (p.right, by + 10)], 3)
            s.set_clip(None)
        c = self.counter_main()
        flick = 0.75 + 0.25 * math.sin(t * 9) * math.sin(t * 5.3)
        pygame.draw.ellipse(s, mix((120, 40, 20), (255, 170, 60), flick), (c.x + 10, c.y - 1, 14, 10))
        for k in range(3):
            lx = c.x + 2 * TILE + 8 + k * 24
            if done:
                pygame.draw.circle(s, (210, 160, 96), (lx + 6, c.y + 2), 7)
                pygame.draw.line(s, (150, 100, 50), (lx + 6, c.y - 4), (lx + 6, c.y + 8))
                pygame.draw.line(s, (150, 100, 50), (lx, c.y + 2), (lx + 12, c.y + 2))
            else:
                pygame.draw.rect(s, (200, 150, 90), (lx, c.y - 4, 12, 11), border_radius=2)
                pygame.draw.rect(s, (160, 110, 60), (lx, c.y - 4, 12, 11), 1, border_radius=2)
        d = self.desk_main()
        for k in range(3):
            cx = d.x + 18 + k * 36
            pygame.draw.rect(s, (236, 230, 214), (cx - 2, d.y - 10, 4, 10))
            fl = 3 + math.sin(t * 11 + k * 2) * 1.2
            pygame.draw.ellipse(s, (255, 214, 120), (cx - 2, d.y - 12 - fl * 2, 4, fl * 2 + 2))
        for R in self.rects.get("F", []):
            cx, cy = R.centerx, R.centery + 4
            for x, y, ph in self.pool_stars:
                b = 0.5 + 0.5 * math.sin(t * 2 + ph)
                s.set_at((int(cx + x), int(cy + y)), mix((30, 30, 80), (220, 220, 255), b))
            ph = (t / 3.5) % 1
            rr = pygame.Rect(0, 0, int(20 + ph * 70), int(8 + ph * 32))
            rr.center = (cx - 8, cy + 2)
            pygame.draw.ellipse(s, mix((90, 90, 170), (12, 16, 44), ph), rr, 1)

    # ---- Ambrine ----
    def _draw_ambrine(self, s, t, flags, fonts):
        for R in self.rects.get("F", []):
            cx, top = R.centerx, R.centery - 30
            for i in range(16):
                ph = (t * 0.9 + i / 16) % 1
                ang = i * 2.4
                d = 6 + ph * 26
                x = cx + math.cos(ang) * d
                y = top + ph * 34 - math.sin(ph * math.pi) * 10 + math.sin(ang) * d * 0.25
                pygame.draw.circle(s, (230, 246, 255), (int(x), int(y)), 1 if ph > 0.5 else 2)
            ph = (t / 2.5) % 1
            rr = pygame.Rect(0, 0, int(30 + ph * 60), int(8 + ph * 20))
            rr.center = (cx, R.centery + 12)
            pygame.draw.ellipse(s, mix((230, 246, 255), (96, 172, 204), ph), rr, 1)
            for x, y, ph2 in self.coin_glints:
                if math.sin(t * 3 + ph2 * 4) > 0.93:
                    gx, gy = int(cx + x), int(R.centery + 10 + y)
                    pygame.draw.line(s, (255, 255, 230), (gx - 3, gy), (gx + 3, gy))
                    pygame.draw.line(s, (255, 255, 230), (gx, gy - 3), (gx, gy + 3))


# --------------------------------------------------------------------------
# Particles
# --------------------------------------------------------------------------

class Particles:
    def __init__(self, plane, seed=3):
        self.plane = plane
        rng = random.Random(seed)
        self.rng = rng
        self.p = []
        n = {"home": 18, "sollow": 110, "hesk": 34, "ambrine": 40}[plane]
        for _ in range(n):
            self.p.append(self._spawn(initial=True))

    def _spawn(self, initial=False):
        r = self.rng
        y = r.uniform(0, MAP_H) if initial else -8
        if self.plane == "sollow":
            return [r.uniform(0, MAP_W), y, r.uniform(16, 38), r.uniform(1, 2.6), r.uniform(0, 6)]
        if self.plane == "hesk":
            return [r.uniform(40, MAP_W - 40), r.uniform(80, MAP_H - 40), r.uniform(-1, 1), r.uniform(-1, 1), r.uniform(0, 6)]
        if self.plane == "ambrine":
            x = r.uniform(-100, MAP_W) if initial else r.uniform(-200, MAP_W - 200)
            return [x, y, r.uniform(16, 36), r.uniform(10, 24), r.uniform(0, 6),
                    r.choice([(244, 150, 170), (250, 190, 110), (240, 120, 120), (255, 220, 140)])]
        return [r.uniform(0, MAP_W), r.uniform(60, MAP_H), r.uniform(-4, 4), r.uniform(-3, 3), r.uniform(0, 6)]

    def update(self, dt, t):
        for i, q in enumerate(self.p):
            if self.plane == "sollow":
                q[1] += q[2] * dt
                q[0] += math.sin(t * 0.8 + q[4]) * 10 * dt
                if q[1] > MAP_H + 6:
                    self.p[i] = self._spawn()
            elif self.plane == "hesk":
                q[2] += self.rng.uniform(-30, 30) * dt
                q[3] += self.rng.uniform(-30, 30) * dt
                sp = math.hypot(q[2], q[3])
                if sp > 22:
                    q[2] *= 22 / sp
                    q[3] *= 22 / sp
                q[0] += q[2] * dt
                q[1] += q[3] * dt
                if not (20 < q[0] < MAP_W - 20 and 60 < q[1] < MAP_H - 20):
                    q[2] = -q[2]
                    q[3] = -q[3]
                    q[0] = min(max(q[0], 21), MAP_W - 21)
                    q[1] = min(max(q[1], 61), MAP_H - 21)
            elif self.plane == "ambrine":
                q[0] += q[2] * dt
                q[1] += q[3] * dt + math.sin(t * 2 + q[4]) * 8 * dt
                q[4] += dt * 2
                if q[1] > MAP_H + 8 or q[0] > MAP_W + 10:
                    self.p[i] = self._spawn()
            else:
                q[0] += q[2] * dt
                q[1] += q[3] * dt
                if not (0 < q[0] < MAP_W and 50 < q[1] < MAP_H):
                    self.p[i] = self._spawn(initial=True)

    def draw(self, s, t):
        if self.plane == "sollow":
            for x, y, _, r, _ in self.p:
                pygame.draw.circle(s, (252, 253, 255), (int(x), int(y)), int(r))
        elif self.plane == "hesk":
            for x, y, _, _, ph in self.p:
                b = 0.5 + 0.5 * math.sin(t * 3 + ph)
                if b > 0.25:
                    glow(s, (int(x), int(y)), 14, (170, 230, 90), b * 0.9)
                    pygame.draw.circle(s, mix((120, 160, 60), (240, 255, 170), b), (int(x), int(y)), 2)
        elif self.plane == "ambrine":
            for x, y, _, _, rot, col in self.p:
                cx, cy = int(x), int(y)
                dx, dy = math.cos(rot) * 4, math.sin(rot) * 2
                pygame.draw.polygon(s, col, [(cx - dx, cy - dy), (cx - dy, cy + dx * 0.5), (cx + dx, cy + dy), (cx + dy, cy - dx * 0.5)])
        else:
            for x, y, _, _, ph in self.p:
                if math.sin(t + ph) > 0:
                    s.set_at((int(x), int(y)), (200, 210, 220))

    def firefly_lights(self):
        if self.plane != "hesk":
            return []
        return [(int(x), int(y), 30, None) for x, y, *_ in self.p]


class Darkness:
    """A dark overlay with soft holes cut out for light sources."""

    def __init__(self, color=(8, 6, 30), alpha=170):
        self.color = color
        self.alpha = alpha
        self.surf = pygame.Surface((MAP_W, MAP_H), pygame.SRCALPHA)

    def draw(self, target, lights):
        self.surf.fill((*self.color, self.alpha))
        for x, y, r, _ in lights:
            hole = radial(r, (0, 0, 0), self.alpha, 0.9)
            self.surf.blit(hole, (x - r, y - r), special_flags=pygame.BLEND_RGBA_SUB)
        target.blit(self.surf, (0, 0))
        for x, y, r, col in lights:
            if col:
                glow(target, (x, y), int(r * 0.8), col, 0.55)


# --------------------------------------------------------------------------
# People
# --------------------------------------------------------------------------

_shadow_cache = {}


def _shadow(w, h):
    key = (w, h)
    if key not in _shadow_cache:
        s = pygame.Surface((w, h), pygame.SRCALPHA)
        pygame.draw.ellipse(s, (0, 0, 0, 70), (0, 0, w, h))
        _shadow_cache[key] = s
    return _shadow_cache[key]


def draw_hair(s, hx, hy, r, look, back):
    """Hair and headwear. `back` draws the layer behind the head."""
    st = look["hair_style"]
    hair = look["hair"]
    acc = look.get("accent") or shade(look["top"], 0.7)
    if back:
        if st == "long":
            pygame.draw.rect(s, hair, (hx - r - 1, hy - r * 0.3, 2 * r + 2, r * 2.1), border_radius=int(r * 0.6))
        elif st == "hood":
            pygame.draw.circle(s, look["top"], (hx, hy), r + max(2, r * 0.3))
            pygame.draw.circle(s, shade(look["top"], 0.85), (hx, hy), r + max(2, r * 0.3), max(1, int(r * 0.12)))
        return
    if st in ("short", "bun", "puffs", "long", "messy"):
        pygame.draw.ellipse(s, hair, (hx - r - 1, hy - r - 2, 2 * r + 2, r + 4))
        pygame.draw.rect(s, hair, (hx - r - 1, hy - r * 0.4, max(2, r * 0.35), r * 0.7))
        pygame.draw.rect(s, hair, (hx + r + 1 - max(2, r * 0.35), hy - r * 0.4, max(2, r * 0.35), r * 0.7))
        if st == "bun":
            pygame.draw.circle(s, hair, (hx, hy - r - r * 0.25), r * 0.5)
        if st == "puffs":
            pygame.draw.circle(s, hair, (hx - r, hy - r * 0.55), r * 0.55)
            pygame.draw.circle(s, hair, (hx + r, hy - r * 0.55), r * 0.55)
        if st == "messy":
            for k in range(-2, 3):
                pygame.draw.polygon(s, hair, [(hx + k * r * 0.4 - r * 0.2, hy - r * 0.7), (hx + k * r * 0.45, hy - r * 1.35), (hx + k * r * 0.4 + r * 0.2, hy - r * 0.7)])
    elif st == "hood":
        pygame.draw.arc(s, shade(look["top"], 0.8), (hx - r - 2, hy - r - 2, 2 * r + 4, 2 * r + 4), 0.3, math.pi - 0.3, max(2, int(r * 0.3)))
        pygame.draw.ellipse(s, hair, (hx - r * 0.75, hy - r * 0.85, r * 1.5, r * 0.6))
    elif st == "wrap":
        pygame.draw.ellipse(s, acc, (hx - r - 2, hy - r * 1.45, 2 * r + 4, r * 1.35))
        pygame.draw.line(s, shade(acc, 0.75), (hx - r, hy - r * 0.55), (hx + r, hy - r * 0.85), max(1, int(r * 0.15)))
        pygame.draw.circle(s, shade(acc, 0.85), (hx + r * 0.7, hy - r * 1.2), r * 0.35)
    elif st == "cap":
        pygame.draw.ellipse(s, hair, (hx - r - 1, hy - r - 1, 2 * r + 2, r + 2))
        pygame.draw.rect(s, (246, 244, 240), (hx - r * 0.85, hy - r * 1.6, r * 1.7, r * 1.0), border_radius=int(r * 0.4))
        pygame.draw.rect(s, (226, 224, 220), (hx - r, hy - r * 0.75, 2 * r, r * 0.3))


def draw_person(s, x, y, look, t, facing=(0, 1), seated=False, moving=False, walk=0.0, phase=0.0):
    """Draw a person whose feet are at (x, y)."""
    k = 0.78 if look.get("child") else 1.0
    x, y = int(x), int(y)
    bob = 0 if moving else math.sin(t * 2.2 + phase) * 0.8
    sh = _shadow(int(24 * k), int(8 * k))
    s.blit(sh, (x - sh.get_width() // 2, y - sh.get_height() // 2 - 1))
    top, bottom, skin = look["top"], look["bottom"], look["skin"]
    acc = look.get("accessory")
    accent = look.get("accent") or shade(top, 0.7)
    dy = 7 * k if seated else 0

    if acc == "long_scarf":
        pts = [(x + 4 * k, y - 26 * k + dy), (x + 9 * k, y - 26 * k + dy), (x + 22 * k, y + 2), (x + 2 * k, y + 4)]
        pygame.draw.polygon(s, accent, pts)
        for i in range(6):
            pygame.draw.circle(s, shade(accent, 1.25), (int(x + (8 + i * 2) * k), int(y - (20 - i * 4) * k + dy)), 1)

    # legs
    if seated:
        pygame.draw.rect(s, bottom, (x - 7 * k, y - 12 * k, 14 * k, 6 * k), border_radius=2)
        pygame.draw.rect(s, shade(bottom, 0.8), (x - 6 * k, y - 7 * k, 4 * k, 7 * k))
        pygame.draw.rect(s, shade(bottom, 0.8), (x + 2 * k, y - 7 * k, 4 * k, 7 * k))
    else:
        sw = math.sin(walk) * 3 * k if moving else 0
        lh = 13 * k
        pygame.draw.rect(s, bottom, (x - 6 * k, y - lh, 5 * k, lh - max(0, sw)))
        pygame.draw.rect(s, bottom, (x + 1 * k, y - lh, 5 * k, lh - max(0, -sw)))
        pygame.draw.rect(s, (40, 34, 34), (x - 6 * k, y - 3 * k - max(0, sw), 5 * k, 3 * k))
        pygame.draw.rect(s, (40, 34, 34), (x + 1 * k, y - 3 * k - max(0, -sw), 5 * k, 3 * k))

    body = pygame.Rect(0, 0, int(18 * k), int(19 * k))
    body.midbottom = (x, int(y - 11 * k + dy - bob))
    hx, hy = x, int(body.y - 7 * k)
    r = int(8 * k * (1.08 if look.get("child") else 1.0))

    draw_hair(s, hx, hy, r, look, back=True)

    arm_swing = math.sin(walk) * 2 * k if moving else 0
    pygame.draw.rect(s, shade(top, 0.82), (body.x - 3 * k, body.y + 2 * k + arm_swing, 4 * k, 13 * k), border_radius=2)
    pygame.draw.rect(s, shade(top, 0.82), (body.right - 1 * k, body.y + 2 * k - arm_swing, 4 * k, 13 * k), border_radius=2)
    pygame.draw.rect(s, top, body, border_radius=int(5 * k))
    if acc == "apron":
        pygame.draw.rect(s, accent, (body.x + 3 * k, body.y + 6 * k, body.w - 6 * k, body.h - 5 * k), border_radius=2)
    if acc == "phone":
        pygame.draw.polygon(s, (230, 230, 236), [(x - 3 * k, body.y), (x + 3 * k, body.y), (x, body.y + 5 * k)])
        pygame.draw.rect(s, accent, (x - 1.5 * k, body.y + 2 * k, 3 * k, 11 * k))
    if acc == "scarf_knot":
        pygame.draw.polygon(s, accent, [(x - 6 * k, body.y), (x + 6 * k, body.y), (x, body.y + 7 * k)])
    if acc == "slate":
        pygame.draw.rect(s, (40, 42, 46), (x - 5 * k, body.y + 4 * k, 10 * k, 8 * k))
        pygame.draw.line(s, (230, 230, 230), (x - 2 * k, body.y + 6 * k), (x - 2 * k, body.y + 10 * k))
        pygame.draw.line(s, (230, 230, 230), (x + 1 * k, body.y + 6 * k), (x + 2 * k, body.y + 10 * k))
    pygame.draw.circle(s, skin, (int(body.x - 1 * k), int(body.bottom - 1 * k + arm_swing)), max(2, int(2.5 * k)))
    pygame.draw.circle(s, skin, (int(body.right + 1 * k), int(body.bottom - 1 * k - arm_swing)), max(2, int(2.5 * k)))

    # head
    pygame.draw.circle(s, skin, (hx, hy), r)
    draw_hair(s, hx, hy, r, look, back=False)
    fx, fy = facing
    if fy < -0.5:
        pygame.draw.circle(s, look["hair"] if look["hair_style"] not in ("hood", "wrap") else look["top"], (hx, hy + 1), r - 1)
    else:
        blink = (t + phase) % 4.2 < 0.12
        ex = int(fx * 2 * k)
        for side in (-1, 1):
            if fx * side < -0.5:
                continue
            px = hx + ex + side * int(3 * k)
            if blink:
                pygame.draw.line(s, (40, 30, 30), (px - 1, hy + 1), (px + 1, hy + 1))
            else:
                pygame.draw.rect(s, (40, 30, 30), (px - 1, hy, 2, 3 * k))

    # held things
    if acc == "mop":
        sway = math.sin(t * 1.4 + phase) * 2
        pygame.draw.line(s, (150, 110, 70), (body.right + 2, body.y - 6), (body.right + 6 + sway, y - 2), 2)
        for i in range(-3, 4):
            pygame.draw.line(s, (200, 200, 190), (body.right + 6 + sway, y - 4), (body.right + 6 + sway + i * 2, y + 2), 1)
    elif acc == "phone":
        pygame.draw.rect(s, (30, 30, 34), (hx + r - 1, hy - 3, 3, 7))
    elif acc == "toy_plane":
        a = t * 2.2 + phase
        px, py = x + math.cos(a) * 15, y - 30 * k + math.sin(a) * 5
        d = -1 if math.sin(a) > 0 else 1
        pygame.draw.ellipse(s, (240, 240, 245), (px - 6, py - 2, 12, 4))
        pygame.draw.line(s, (220, 60, 60), (px - 1, py - 4), (px + 1, py + 4), 3)
        pygame.draw.line(s, (220, 60, 60), (px - 5 * d, py - 3), (px - 5 * d, py), 2)
    elif acc == "knitting":
        n = math.sin(t * 6 + phase) * 2
        cy = body.bottom - 4 * k
        pygame.draw.line(s, (220, 210, 180), (x - 7 * k, cy - 6 * k + n), (x + 5 * k, cy + 2 * k), 1)
        pygame.draw.line(s, (220, 210, 180), (x + 7 * k, cy - 6 * k - n), (x - 5 * k, cy + 2 * k), 1)
        pygame.draw.rect(s, accent, (x - 6 * k, cy, 12 * k, 4 * k), border_radius=2)
        pygame.draw.circle(s, accent, (int(x + 12 * k), int(y - 4 * k)), max(2, int(4 * k)))
    elif acc == "feather":
        fxp, fyp = body.right + 2, body.bottom - 6 * k
        pygame.draw.ellipse(s, (250, 250, 252), (fxp - 2, fyp - 10, 5, 12))
        pygame.draw.line(s, (200, 200, 210), (fxp, fyp - 9), (fxp + 1, fyp + 3))
    elif acc == "lantern":
        lx, ly = body.right + 4, body.y + 4 + math.sin(t * 2 + phase) * 2
        pygame.draw.line(s, (160, 150, 120), (body.right, body.y + 8), (lx, ly), 1)
        pygame.draw.ellipse(s, (255, 236, 170), (lx - 4, ly - 3, 8, 7))
        pygame.draw.polygon(s, (255, 214, 150), [(lx - 4, ly), (lx - 9, ly - 4), (lx - 6, ly + 3)])
        pygame.draw.polygon(s, (255, 214, 150), [(lx + 4, ly), (lx + 9, ly - 4), (lx + 6, ly + 3)])
    elif acc == "bird":
        bx, by = x, body.bottom - 3 * k
        pygame.draw.ellipse(s, (150, 104, 62), (bx - 5, by - 3, 10, 6))
        pygame.draw.circle(s, (150, 104, 62), (bx + 4, by - 3), 3)
        pygame.draw.polygon(s, (230, 180, 60), [(bx + 6, by - 3), (bx + 9, by - 2), (bx + 6, by - 1)])
    elif acc == "box":
        bx, by = x, body.bottom - 2 * k
        pygame.draw.rect(s, (140, 100, 60), (bx - 7, by - 5, 14, 10), border_radius=1)
        pygame.draw.rect(s, (100, 70, 40), (bx - 7, by - 5, 14, 10), 1, border_radius=1)
        pygame.draw.circle(s, (230, 200, 90), (bx, by), 1)
    elif acc == "bread":
        pygame.draw.ellipse(s, (214, 164, 96), (body.right - 4, body.bottom - 8, 14, 8))
        pygame.draw.line(s, (176, 120, 60), (body.right, body.bottom - 6), (body.right + 3, body.bottom - 2))
    elif acc == "quill":
        pygame.draw.line(s, (250, 250, 250), (body.right + 1, body.bottom - 2), (body.right + 7, body.bottom - 14), 2)


def draw_suitcase(s, x, y):
    x, y = int(x), int(y)
    sh = _shadow(16, 6)
    s.blit(sh, (x - 8, y - 4))
    pygame.draw.rect(s, (186, 74, 58), (x - 7, y - 15, 14, 14), border_radius=3)
    pygame.draw.rect(s, (150, 56, 44), (x - 7, y - 15, 14, 14), 1, border_radius=3)
    pygame.draw.line(s, (230, 200, 120), (x - 7, y - 9), (x + 6, y - 9), 1)
    pygame.draw.line(s, (90, 90, 96), (x, y - 15), (x, y - 22), 2)
    pygame.draw.line(s, (90, 90, 96), (x - 3, y - 22), (x + 3, y - 22), 2)
    pygame.draw.circle(s, (40, 40, 44), (x - 5, y - 1), 2)
    pygame.draw.circle(s, (40, 40, 44), (x + 5, y - 1), 2)


def draw_portrait(s, rect, look, t, talking=False, bg=(60, 70, 90)):
    """Head-and-shoulders portrait for the dialogue box and journal."""
    rect = pygame.Rect(rect)
    u = rect.w / 100.0
    prev_clip = s.get_clip()
    pygame.draw.rect(s, shade(bg, 0.55), rect, border_radius=int(10 * u))
    inner = rect.inflate(int(-6 * u), int(-6 * u))
    vgrad(s, inner, shade(bg, 0.95), shade(bg, 0.6))
    s.set_clip(inner)
    cx = rect.centerx
    cy = int(rect.y + 46 * u)
    r = int(24 * u * (1.08 if look.get("child") else 1.0))
    top = look["top"]
    acc = look.get("accessory")
    accent = look.get("accent") or shade(top, 0.7)

    draw_hair(s, cx, cy, r, look, back=True)
    pygame.draw.ellipse(s, top, (cx - 40 * u, rect.y + 78 * u, 80 * u, 50 * u))
    pygame.draw.rect(s, shade(look["skin"], 0.9), (cx - 7 * u, cy + r - 6 * u, 14 * u, 16 * u))
    if acc == "apron":
        pygame.draw.rect(s, accent, (cx - 22 * u, rect.y + 86 * u, 44 * u, 30 * u), border_radius=int(4 * u))
    if acc == "phone":
        pygame.draw.polygon(s, (230, 230, 236), [(cx - 10 * u, rect.y + 79 * u), (cx + 10 * u, rect.y + 79 * u), (cx, rect.y + 92 * u)])
        pygame.draw.rect(s, accent, (cx - 4 * u, rect.y + 84 * u, 8 * u, 20 * u))
    if acc in ("scarf_knot", "long_scarf"):
        pygame.draw.ellipse(s, accent, (cx - 24 * u, rect.y + 74 * u, 48 * u, 14 * u))
    if acc == "slate":
        pygame.draw.rect(s, (40, 42, 46), (cx - 12 * u, rect.y + 86 * u, 24 * u, 16 * u))
        pygame.draw.line(s, (230, 230, 230), (cx - 3 * u, rect.y + 90 * u), (cx - 3 * u, rect.y + 98 * u), max(1, int(u * 2)))
        pygame.draw.line(s, (230, 230, 230), (cx + 3 * u, rect.y + 90 * u), (cx + 5 * u, rect.y + 98 * u), max(1, int(u * 2)))

    pygame.draw.circle(s, look["skin"], (cx, cy), r)
    pygame.draw.circle(s, shade(look["skin"], 0.92), (cx - r, cy + 3 * u), 4 * u)
    pygame.draw.circle(s, shade(look["skin"], 0.92), (cx + r, cy + 3 * u), 4 * u)
    draw_hair(s, cx, cy, r, look, back=False)

    blink = t % 3.7 < 0.13
    for side in (-1, 1):
        ex = cx + side * 9 * u
        if blink:
            pygame.draw.line(s, (40, 30, 30), (ex - 3 * u, cy + 3 * u), (ex + 3 * u, cy + 3 * u), max(1, int(2 * u)))
        else:
            pygame.draw.ellipse(s, (40, 30, 30), (ex - 2.5 * u, cy, 5 * u, 6.5 * u))
            pygame.draw.circle(s, (255, 255, 255), (int(ex + 1 * u), int(cy + 1.5 * u)), max(1, int(1 * u)))
        pygame.draw.line(s, shade(look["hair"], 0.9), (ex - 4 * u, cy - 5 * u), (ex + 4 * u, cy - 6 * u + side * 0), max(1, int(1.6 * u)))
    blush = pygame.Surface((int(10 * u), int(6 * u)), pygame.SRCALPHA)
    pygame.draw.ellipse(blush, (230, 110, 110, 60), blush.get_rect())
    s.blit(blush, (cx - 18 * u, cy + 8 * u))
    s.blit(blush, (cx + 8 * u, cy + 8 * u))
    mouth_open = talking and int(t * 10) % 2 == 0
    if mouth_open:
        pygame.draw.ellipse(s, (110, 50, 50), (cx - 4 * u, cy + 11 * u, 8 * u, 6 * u))
    else:
        pygame.draw.arc(s, (110, 50, 50), (cx - 6 * u, cy + 7 * u, 12 * u, 8 * u), math.pi + 0.4, 2 * math.pi - 0.4, max(1, int(1.6 * u)))
    s.set_clip(prev_clip)
